IBPS PO Mains 2025 Memory Based - 12-Oct-2025


### Directions (1 -5): Study the following information carefully and answer the questions given below. There are three rows, i.e., row 1, row 2, and row 3. Row 1 is north of row 2, and row 2 is north of row 3. Four persons sit in row 1 and row 3 each, and eight persons sit in row 2. Four persons from the left end in row 2 face the persons who sit in row 1, and the remaining four persons face the persons who sit in row 3 (left to right means west to east). The persons sitting in row 1 face south, and the persons sitting in row 3 face north. All the persons sit opposite to one person. The one who sits opposite to A, sits third to the left of Y. Y doesn’t face south. Two persons sit between Y and M. The one who sits opposite to M, sits two places away from O who doesn’t face north. As many persons sit between A and O as between R and T. T doesn’t face north and doesn’t sit in row 2. R doesn’t sit at the extreme ends of the row. The one who sits opposite to R, sits fourth to the right of L. Three persons sit between L and K. As many persons sit to the left of K as to the right of E. S and N are immediate neighbours, but both S and N doesn’t face south. S is not an immediate neighbour of E and A. J is opposite to X who doesn’t sit in row 2. The number of persons sit between J and K is two less than the number of persons sit to the right of P. P doesn’t face south. Y doesn’t face C. H doesn’t face north.


## Q1. How many persons sit between L and the one who faces X?

(a) Five

(b) Three

(c) Six

(d) Four

(e) Two


## Q2. The one who sits immediate left of Y, sits opposite to the person who sits _________ of K?

(a) Third to the right

(b) Fifth to the left

(c) Fifth to the right

(d) Fourth to the right

(e) Sixth to the left


## Q3. Which of the following statements is true?

(a) A and N are not immediate neighbours

(b) H is the only neighbour of O

(c) The number of persons sit to the right of S is three less than the number of persons sit between M and Y

(d) O sits opposite to E

(e) Y sits in row 2


## Q4. Who sits opposite to the person who sits fourth to the right of H?

(a) C

(b) X

(c) T

(d) R

(e) M


## Q5. If C is related to S and in the same way L is related to P, then who among the following is related to A?

(a) Y

(b) E

(c) S

(d) K

(e) M


### Directions (6 -10): Study the following information carefully and answer the questions given below: There are six persons- A, B, C, D, E and F, designated at six different positions in a company – Manager, Assistant Manager (AM), Senior Executive (SE), Junior Executive (JE), Team Leader (TL) and HR Specialist each from a different state- Maharashtra, Tam il Nadu, Gujarat, Uttar Pradesh, Haryana and Rajasthan and like six different sports- Cricket, Football, Tennis, Badminton, Basketball and Hockey. All information is not necessarily used in same order as given. F is designated three persons junior to the one who is from Rajasthan and immediately senior to the one who likes Tennis. One person is designated between the ones who like tennis and cricket. No person is designated between the one who likes cricket and t he one who is from Uttar Pradesh. Two persons are designated between the one who is from Uttar Pradesh and the one who likes Hockey. D is designated immediate junior to the one who likes Hockey and senior to

A. The one who is from Tamil Nadu designated th ree persons senior to A. C is designated junior to Assistant Manager. Two persons are designated between C and the one who is from Gujarat. B is designated junior to the one who is from Gujarat and immediate senior to the one who likes Basketball. E is three persons senior to the one who is from Maharashtra and doesn’t like Football.


## Q6. Who among the following is designated as Senior Executive?

(a) E

(b) B

(c) A

(d) D

(e) F


## Q7. The person who likes tennis is from which state?

(a) Maharashtra

(b) Haryana

(c) Rajasthan

(d) Uttar Pradesh

(e) Gujarat


## Q8. Who likes Football and is designated at which position?

(a) The person from Rajasthan, TL

(b) The person from Maharashtra, JE

(c) The person from Uttar Pradesh, TL

(d) The person from Tamil Nadu, SE

(e) A, HR Specialist


<!-- Page 2 -->


## Q9. Which of the following combinations is correct?

(a) A – Senior Executive – Football

(b) E – Manager – Hockey

(c) B – Assistant Manager – Hockey

(d) D – Junior Executive – Badminton

(e) F – Junior Executive – Cricket


## Q10. How many persons are designated between the ones who like Badminton and the one who is from Maharashtra?

(a) One

(b) Three

(c) None

(d) Four

(e) Two


### Directions (11-13): Each question below is followed by two statements numbered I and II. You have to decide whether the data provided in the statements are sufficient to answer the question. Read both statements carefully and give your answer.


## Q11. Six persons – A, B, C, D, E, and F – sit in a row and face north. What is the position of E with respect to C?

I. D sits second to the right of C. A sits to the left of D. F sits at an extreme right end of the row.

II. E is an immediate neighbour of D. B sits to the left of E. A is not an immediate neighbour of B and doesn’t sit at the extreme ends of the row.

(a) Data given in both statements I and II together are sufficient to answer

(b) Data given in statement I alone is sufficient to answer

(c) Data given in statement II alone is sufficient to answer

(d) Data given in both statements I and II together are not sufficient to answer.

(e) Data given in either statement I or statement II alone is sufficient to answer the question


## Q12. Six boxes – P, Q, R, S, T, and U – are kept one above the other. What is the position of box T from the bottom?

I. Two boxes are placed between box T and box U. As many boxes are placed above box T as below box S. Box S is placed adjacent to box R. Box Q is placed above box P.

II. Only three boxes are placed below box Q. One box is placed between box S and box Q. The number of boxes placed above box S is same as the number of boxes placed below box U. Box P is placed below box R but above box T. Box T is not placed at the bottommost position.

(a) Data given in both statements I and II together are sufficient to answer

(b) Data given in statement I alone is sufficient to answer

(c) Data given in statement II alone is sufficient to answer

(d) Data given in both statements I and II together are not sufficient to answer

(e) Data given in either statement I or statement II alone is sufficient to answer the question


## Q13. In which direction is point V with respect to point X?

I. Point Z is to the east of point X. Point Y is 8m north of point Z. Point V is 5m to the west of Point Y.

II. Point X is to the west of point Y. Point X is 4m south of point W. Point Y is 6m north of point B. Point B is to the east of Point V.

(a) Data given in both statements I and II together are sufficient to answer

(b) Data given in statement I alone is sufficient to answer

(c) Data given in statement II alone is sufficient to answer

(d) Data given in both statements I and II together are not sufficient to answer

(e) Data given in either statement I or statement II alone is sufficient to answer the question


## Q14. Seven letters are arranged to form a meaningful word. Only two letters are placed between E and A. P is two places to the right of E. A is two places to the left of R. As many letters are there to the left of D as to the right of R. S is placed to the left of I. Now, if only one meaningful word is formed then, which letter is fifth letter from the left end of the newly formed word. If no meaningful word is formed, mark X as your answer, and if more than one such word is formed, mark Y as your answer?

(a) X

(b) S

(c) D

(d) Y

(e) A


## Q15. In the number ‘8472674634’, if all the even digits are subtracted by 1 and all the odd digits are added by 1. After that arrange 2 nd, 4 th, 6 th and 8 th digits in ascending order from left and rest of the digits in descending order after them. Now find the sum of the third odd digit from the right end and third even digit from the left end, in the new number formed after rearrangement?

(a) 7

(b) 13

(c) 28

(d) 9

(e) 14


### Directions (16 -20): A word and number arrangement machine when given an input line of numbers rearranges them following a particular rule in each step. The following is an illustration of an input and rearrangement.

Input: rope 37 flip 44 code 23 leaf 35 jump 56

Step I: cdoe rope 37 flip 44 leaf 35 jump 56 6

Step II: filp cdoe rope 37 44 leaf jump 56 6 15

Step III: jmup filp cdoe rope 44 leaf 56 6 15 21

Step IV: laef jmup filp cdoe rope 56 6 15 21 16


<!-- Page 3 -->

Step V: rpoe laef jmup filp cdoe 6 15 21 16 30 And Step V is the last step of the rearrangement for the given input. As per the rules followed in the above steps, find out in each of the following questions the appropriate steps for the given input.

Input: dive 54 lime 26 bark 19 frog 56 mist 74


## Q16. Which element is not present in Step II?

(a) dvie

(b) 56

(c) frog

(d) bark

(e) 74


## Q17. Which combination of words and numbers is present in Step IV?

(a) dvie brak mist 74 9

(b) msit lmie forg

(c) 56 mist 74 9

(d) forg dvie 8 brak

(e) None of these


## Q18. What will be the sum of all the numbers which are multiple of 3 in Step V?

(a) 55

(b) 51

(c) 44

(d) 63

(e) 78


## Q19. In which step, does the combination of numbers and letters "20 30 28" appear?

(a) Step II

(b) Step I

(c) Step IV

(d) Step III

(e) Step V


## Q20. Which element is second to the left of third element from right end in Step I?

(a) 54

(b) lime

(c) frog

(d) 26

(e) mist


### Directions (21-25): Study the information carefully and answer the questions that follow. Eight persons — P, Q, R, S, T, U, V and W — sit around a circular table. Four of them face the centre while the remaining four face outside. S sits second to the right of P. O sits three places away from S. V sits second to the left of O. O and P face the direction opposite to each other. R and O are immediate neighbours. T sits second to the right of R and is not an immediate neighbour of V. U sits second to the left of Q and is not R’s and P’s neighbour. Q and T face the same direction but are not immediate neighbours. S doesn’t face inside. After some time, they sit in a row such that those who faced inside now face North and those who faced outside now face South. U sits second from left end of the row. T is an immediate neighbour of U but doesn’t sit at the extreme ends of the row. One of the immediate neighbours of U face south. S sits to the left of T. R is not V’s neighbour.

Note I: The one who sits at the extreme right end doesn’t face south and is not a consonant.

Note II: More than two persons doesn’t face the same


### direction.

Note III: Immediate neighbour of T faces the direction opposite to each other.

Note IV: There is only one of the pair of persons in circular seating arrangement who sit opposite to each other and are immediate neighbours in linear seating arrangement.


## Q21. What is the position of the person who sits immediate left of T in the circular seating arrangement, with respect to R in linear seating arrangement?

(a) Fourth to the left

(b) Fifth to the right

(c) Fifth to the left

(d) Fourth to the right

(e) Third to the right


## Q22. How many persons sit to the right of P in the linear seating arrangement?

(a) Two

(b) Three

(c) Four

(d) Five

(e) More than five


## Q23. The who sits opposite to R in the circular seating arrangement, sits immediate right of _____ in linear seating arrangement?

(a) V

(b) O

(c) U

(d) S

(e) R


## Q24. The number of persons sit between O and P (when counted from left of O) in circular seating arrangement, is one less than the number of persons sit between ___ and ____ in linear seating arrangement?

(a) U, P

(b) O, V

(c) S, Q

(d) T, Q

(e) R, V


## Q25. Which of the following statements is true?

(a) V faces North.

(b) Two persons sit between T and P in circular seating arrangement when counted from right of T.

(c) O faces outside in circular seating arrangement.

(d) Q is not O’s neighbour in linear seating arrangement.

(e) Two persons sit between U and P in linear seating arrangement.


<!-- Page 4 -->


### Directions ( 26-29): Read the given information carefully and answer the questions that follow: In a certain code language, “summer beach coconut breeze” is coded as “&3 $3 #3 &3” “rays cream summer travel” is coded as “@3 $3 &3 &4” “sand oranges mango season” is coded as “@3 #4 $3 &2” “pool bath hydrate heat” is coded as “@2 @3 #5 @2”


## Q26. What will be the code for ‘blazing’?

(a) #5

(b) @4

(c) #3

(d) @5

(e) $3


## Q27. What will be the code for ‘rolling waves’?

(a) @3 #4

(b) #4 #3

(c) #5 @6

(d) @5 $3

(e) #4 $3


## Q28. Which of the following pair is correctly matched?

(a) Horizon - #5

(b) Glory - $3

(c) Serene - $3

(d) Noise- $2

(e) More than one option is correct


## Q29. What will be the code for ‘escape’?

(a) #3

(b) &3

(c) #4

(d) $4

(e) #5


## Q30. Statement: A company decided to implement a mentorship program where senior employees guide junior employees. The program lasted for six months and was followed by a performance evaluation. The results showed that mentees improved their skills significantly, and 80% of them showed better results in their respective projects. Mentors also reported greater job satisfaction and a stronger sense of achievement.

Assumptions:

I. Mentees showed significant improvement due to the guidance they received.

II. Senior employees always have the time to mentor junior employees effectively.

III. Mentorship programs contribute to the growth of both mentees and mentors.

IV. Mentees would have improved even without the mentorship program. Which of the following assumptions can be drawn from the statement?

(a) Only I and II follow

(b) Only II and IV follow

(c) Only III follows

(d) Only I and III follow

(e) Only IV follows


## Q31. A retail chain, facing declining sales, introduced a customer loyalty program offering rewards for repeat purchases. Within a year, the chain saw a 30% increase in customer retention and a 15% increase in sales from returning customers. Managers believe the loyalty program played a significant role in this positive change. However, some believe it could have been due to other market factors such as product quality improvement or seasonal trends. Which of the following conclusions is the most accurate?

(a) The loyalty program directly contributed to higher sales and customer retention.

(b) Customer loyalty programs are always effective in boosting sales.

(c) Market factors and product quality improvement were the main reasons for the sales increase.

(d) The loyalty program had no effect on customer retention or sales.

(e) The loyalty program was the only factor responsible for the increase in sales and customer retention.


## Q32. Statement: In a household, members have been feeling overwhelmed with the number of household tasks, and the quality of work has been decreasing. The family decided to create a schedule assigning each member specific chores, such as cleaning, cooking, and grocery shopping, on different days of the week. Course of Actions

I. Assigning specific chores to family members will ensure that tasks are completed on time.

II. Creating a schedule will reduce confusion and help family members manage their time more effectively.

III. A fixed schedule for chores will ensure fair distribution of work among family members. Which of the following courses of action is the most appropriate?

(a) Only I and III

(b) Only I and II

(c) Only III

(d) Only I

(e) Only II


## Q33. Statement: A popular electronic store recently launched a sale offering a 30% discount on smartphones. The sale was advertised extensively, and many customers visited the store with the hope of getting good deals. However, some customers complained that the availabl e stock was limited, and they couldn't buy the model they wanted. The store management decided to extend the sale by another week to accommodate the demand.


<!-- Page 5 -->

What could be the possible reason behind extending the sale by another week?

(a) The store wanted to clear out old stock before the new models arrived.

(b) The store realized that many customers had not been able to take advantage of the sale due to limited stock.

(c) The store planned to introduce new models with better features after the sale.

(d) The store needed more time to adjust prices on the discounted items.

(e) The store management thought that the sale was not generating enough revenue.


## Q34. Statement: Employees of a software company have been planning a 3-day weekend trip to the mountains. The HR department initially suggested that the company would bear 70% of the total expense if at least 40 employees joined. However, only 25 employees registered wit hin the first week. To encourage more participation, the HR decided to extend the registration deadline and send out a reminder email to all departments. What could be the possible assumption behind the HR department’s decision?

(a) Employees were not aware of the initial deadline for registration.

(b) Extending the registration deadline and sending reminders will motivate more employees to join the trip.

(c) The company wants to ensure that all departments have equal participation in the trip.

(d) Employees prefer spending weekends at home rather than going on trips.

(e) The HR department had already booked the venue and needed more participants to justify the cost.


## Q35. Statement: In the city’s main market, several flower shops have extended their opening hours till late evening. It has also been observed that a large number of people are visiting temples and organizing family functions these days. Which of the following best explains the situation described above?

(a) Flower shops are facing losses and are trying to recover by working extra hours.

(b) The shopkeepers want to increase their profits by keeping their shops open for longer hours.

(c) The government has announced a new policy to promote flower trading.

(d) The increased number of religious visits and family functions has led to greater demand for flowers.

(e) The suppliers have reduced the prices of flowers, encouraging late-night sales.


## Q36. Statement: In metro cities, people often spend long hours commuting due to heavy traffic, while in smaller towns, travel time is usually shorter, allowing people to spend more time with their families. To address the issue of long commuting hours, several metro city offices have introduced flexible working hours and work -from-home options.

Courses of Action:

I. Employees in smaller towns should also be given flexible work options even if they don’t face long commuting hours.

II. Work-from-home options can reduce traffic congestion and save travel time for employees.

III. Introducing flexible working hours can help employees in metro cities maintain a better work-life balance. Which of the following courses of action is/are most appropriate?

(a) Only I and II

(b) Only II

(c) Only I

(d) Only I and III

(e) Only II and III


### Directions (37-40): Study the information carefully and answer the questions that follow. There are four persons John, Albert, Nathon and Edison went on different directions from point P in alphabetical order as per their name. Person travels for the second time only after each person has travelled once and so on. Example: Four persons Derek, Gabriel, Thomas and Ben start their journey from point B. ♥4K, ♦8L, ♣11M, ♠2O, ♣7T, ♥8R, ♣1L, ♠4V Now as per the given information, Ben walks towards the north for 4m from Point B, then Derek walks towards south for 8m from Point B, then Gabriel walks towards the west for 11m from Point B and so on followed by Thomas. After each person’s walk, once again they walk in alphabetical order. The given distance is travelled by Ben 2nd time, then Derek and so on followed by Gabriel, then followed by Thomas.

Note 1: ♠ means east, ♣ means west, ♥ means north, ♦ means south.

Note 2: Symbol represents direction, digit represents distance and letter represents the point where the person reached.

Note 3: Instruction is followed from left to right respectively. Now based on the above example, find the direction and distance of John, Albert, Nathon and Edison. ♣7A, ♦3M, ♠8F, ♥7G ♥4R, ♠5E, ♥9C, ♣10D ♠8O, ♠7K, ♣2X, ♦10Y ♦2N, ♥3Z, ♦5W, ♠6T


## Q37. In which direction is point T with respect to point K?

(a) West

(b) North-west

(c) South-west

(d) North-east

(e) East


<!-- Page 6 -->


## Q38. What is the shortest distance between point C and point K?

(a) 160m

(b) √160m

(c) 13√26m

(d) √13m

(e) √14m


## Q39. Which of the following statements is/are not true?

I. Nathon’s final point is to south-west of Point G.

II. John’s final point is to the north-east of Point P.

III. Point D is to the south-west of Point N.

(a) Only II and III

(b) Only I and II

(c) Only I

(d) Only III

(e) All I, II and III


## Q40. In which direction is Johns’s final position with respect to point E?

(a) North-west

(b) North-east

(c) South-west

(d) North

(e) East


## Q41. In the given question five sentences are given in which one is not coherent with others. Choose the incoherent statement as your answer.

(a) As cities expand into previously undeveloped land, the natural habitats of many animal species are rapidly disappearing.

(b) Noise pollution from traffic and construction disrupts the mating calls and migration patterns of birds.

(c) Urban planning initiatives now often include green corridors to help animals safely traverse city environments.

(d) The popularity of minimalist architecture has increased significantly in urban apartment design.

(e) Some species, like raccoons and pigeons, have adapted to urban environments and even thrive in densely populated areas.


## Q42. In the given question five sentences are given in which one is not coherent with others. Choose the incoherent statement as your answer.

(a) Eating fruits and vegetables provides your body with essential vitamins and minerals.

(b) The heart pumps blood through arteries and veins to all parts of the body.

(c) Whole grains are a good source of fiber and help with digestion.

(d) Drinking water instead of sugary drinks can help prevent weight gain.

(e) Too much processed food can increase the risk of health problems like diabetes.


## Q43. A paragraph is given below, followed by five alternatives. Select the one that most accurately conveys the same idea and context as the original. An empty plate is more than a sign of hunger. It reflects inequality, waste, and the failure to make food security a collective priority.

(a) The image of an empty plate embodies not only human deprivation but the collective moral failure of societies that tolerate hunger amid abundance and structural inefficiency.

(b) The sight of an empty plate simply mirrors individual hardship and bears no connection to wider issues of inequality, policy negligence, or moral accountability.

(c) The notion of an empty plate has lost significance as improved welfare policies and efficient food systems have largely eliminated hunger and malnutrition nationwide.

(d) The symbol of an empty plate now represents personal dietary choice rather than any social or administrative neglect related to food security and equitable distribution.

(e) The meaning of an empty plate has changed with time, signifying temporary scarcity rather than enduring inequality or the state’s indifference toward systemic hunger.


## Q44. A paragraph is given below, followed by five alternatives. Select the one that most accurately conveys the same idea and context as the original. Recent studies reveal that exposure to microscopic air pollutants does not merely affect the lungs. These tiny particles penetrate the bloodstream, elevating the risk of heart attacks and strokes.

(a) Recent evidence suggests that airborne particles strengthen immunity and reduce the overall incidence of heart-related diseases among urban residents.

(b) Microscopic particles remain confined to the respiratory tract, causing only mild and temporary irritation without any long-term cardiac consequences.

(c) Air pollution primarily damages the nervous system, with negligible impact on vascular or coronary functioning in the general population.

(d) Fine particulate pollutants enter the circulatory system and contribute significantly to cardiovascular complications, proving that air quality is directly linked to heart health.

(e) Particulate matter affects only outdoor workers, leaving the cardiovascular health of indoor populations largely unharmed by polluted air.


## Q45. Rearrange the following sentences to form a meaningful paragraph.

(A) It helps in storing water for future use.

(B) Rainwater harvesting is a simple conservation method.

(C) This collected water can be used for daily needs.

(D) This method is especially useful in drought-prone areas.

(a) BACD

(b) DABC

(c) ABDC

(d) CBDA

(e) No rearrangement required


<!-- Page 7 -->


### Directions ( 46-55): Read the following passage and answer the given questions. For most Africans, air travel remains a fairytown fantasy— enchanting in theory, but unreachable in practice. Despite the continent's growing population of over 1.4 billion, less than 2% of Africans fly regularly. A mix of protectionist policies, poor infrastructure, and high costs has made air travel a luxury enjoyed by only the elite few. Intra-African flights are among the most expensive globally. A round -trip ticket between Lagos and Nairobi —two key African cities—can exceed $2000, often more than the cost of flying to Europe. This exorbitant pricing begets from excessive fuel surcharges, airport taxes, and a chronic lack of competition. Many African governments have long banned foreign airlines from operating domestic or inter - country routes. While intended to protect national carriers, this fortress mentality has produced the opposite effect: weak airlines, limited connectivity, and high fares. This inward -looking approach has had bizarre consequences. It is not uncommon for African passengers to transit through Paris, Istanbul, or Dubai just to reach a neighboring country. The system is illogical and inefficient. While the Yamoussoukro Decision (1999) and its successor, the Single African Air Transport Market (SAATM), aimed to reform the sector, implementation has been sluggish. Only a handful of countries have put these liberalization policies into action. The lack of reform causes stagnation. Without open skies, real competition cannot emerge. Without competition, prices remain high. And without affordable air travel, continental trade and integration suffer. In contrast, facilitates not only the movement of people but the flow of goods, ideas, and economic growth. African aviation never truly got off the ground. To change this, leaders must prioritize regional cooperation, deregulation, and accessibility over isolation and control. Unless bold reforms are enacted, African skies will remain grounded in fantasy —a fairytown spectacle that benefits the few while excluding the many.


## Q46. What best expresses the author’s opinion about African aviation?

(a) African nations should continue protecting national carriers through restrictive policies.

(b) The aviation sector should focus only on domestic connectivity.

(c) African leaders must embrace open skies and deregulation for real progress.

(d) The aviation industry in Africa is thriving and affordable for most citizens.

(e) The best way to improve aviation is to ban all foreign involvement.


## Q47. Which of the following words highlighted in the passage is contextually incorrect?

(a) facilitates

(b) begets

(c) connectivity

(d) unreachable

(e) All are correct


## Q48. Which of the following is TRUE according to the passage?

(A) A return flight between Lagos and Nairobi usually costs less than $500.

(B) Intra -African flights are often cheaper than flights to Europe.

(C) A round -trip ticket between two African cities can exceed $2000.

(a) Only A

(b) Both B and C

(c) Only B

(d) Only C

(e) All A, B, C


## Q49. What does the phrase “got off the ground” mean?

(a) To gain attention before quickly fading away

(b) To fail to launch due to lack of resources

(c) To achieve long-term success after a temporary failure

(d) To remain stuck at the planning stage indefinitely

(e) To begin or launch successfully after preparation


## Q50. Which of the following statements is/are CORRECT according to the passage? (I) The Yamoussoukro Decision was intended to open African airspace. (II) SAATM has been implemented successfully across all African nations. (III) Intra-African connectivity remains limited due to high costs.

(a) Only (I)

(b) Both (I) and (III)

(c) Only (II)

(d) All (I), (II), and (III)

(e) Both (II) and (III)


## Q51. Which of the following is the most likely reason for the phrase “fairytown fantasy” to describe African aviation?

(a) African aviation is filled with fictional airline branding and marketing.

(b) The aviation industry in Africa is controlled entirely by foreign companies.

(c) Most African airports operate only luxury flights for tourists.

(d) African countries refuse to participate in any form of regional aviation pacts.

(e) Air travel seems glamorous and promising but is inaccessible for most.


## Q52. What does the author mean by “fortress mentality”?

(a) A collaborative mindset where African nations build protective trade alliances

(b) An isolationist policy stance where countries protect their markets by avoiding external competition

(c) A financial model focused on fortifying airport infrastructure through regional investments

(d) A regulatory framework designed to expand African aviation into foreign markets

(e) A defensive strategy used by airlines to prevent cyberattacks and data breaches


<!-- Page 8 -->


## Q53. Based on the passage, which of the following best describes the relationship between competition and affordability in African aviation?

(a) Increased competition has led to unfair pricing and overcapacity.

(b) Competition is unrelated to ticket pricing in African aviation.

(c) A lack of competition keeps prices artificially low to protect consumers.

(d) Limited competition contributes to higher fares and poor connectivity.

(e) Foreign competition would reduce airline quality and safety.


## Q54. Which of the following statement(s) is/are true? (I) Fewer than 2% of Africans travel by air regularly. (II) Flights between African cities are often cheaper than flights to Europe. (III) Some African travelers must transit through non - African cities to reach nearby countries.

(a) Only (I)

(b) Both (I) and (III)

(c) Only (II)

(d) All (I), (II), and (III)

(e) None of the above


## Q55. According to the passage, what is the primary consequence of restricting foreign airlines from operating intra-African routes?

(a) It improves safety and increases national employment in aviation.

(b) It fosters rapid development of domestic infrastructure.

(c) It encourages more domestic passengers to fly at affordable rates.

(d) It weakens competition, increases prices, and limits connectivity.

(e) It helps national carriers establish global partnerships.


### Directions (56 -60): Choose the most appropriate replacement for each highlighted phrase in the passage so that the paragraph becomes both contextually suitable and grammatically correct. Artificial intelligence has transformed how students learn by expanding course catalogs online (A), reliable help at their fingertips. With AI chat assistants and course platforms, clarities long resolved (B) for the next class are resolved in minutes. Explanations, examples, and step -by- step solutions arrive on demand, so learners are no longer dependent on classroom lectures to keep moving forward. This immediacy reduces anxiety, sustains momentum, and turns confusion into curiosity. AI also personalizes study. Adaptive systems diagnose weak areas, recommend targeted practice, and adjust difficulty in real time. Vocabulary drills, grammar checks, and writing feedback become continuous, specific, and data -driven. In the traditional classroom (C), AI creates timed quizzes, analyses mistakes, and suggests revision plans aligned to the syllabus. Visual summaries, flashcards, and audio notes capture transforming information (D) and busy schedules. Beyond speed and personalization, AI expands access. Students in remote areas can consult high -quality tutors anytime; translations and text -to-speech remove language and reading barriers. Collaboration tools help peers co - create notes and track progress transparently. Of course, smart use matters. Therefore, every app dictates, (E) compare multiple explanations, and practice solving without prompts. Used thoughtfully, AI becomes a study partner that accelerates understanding, builds confidence, and gives every learner the freedom to learn— anytime, anywhere. every day.


## Q56. Which of the following should replace the highlighted phrase (A)?

(a) with round-the-clock tools in use

(b) by putting instant

(c) in the new digital climate

(d) No replacement required

(e) alongside evolving classroom policies


## Q57. Which of the following should replace the highlighted phrase (B)?

(a) schedules that used to slip

(b) messages that often delayed replies

(c) doubts that once waited

(d) forms that remained pending

(e) No replacement required


## Q58. Which of the following should replace the highlighted phrase (C)?

(a) For exam preparation

(b) No replacement required

(c) During leisure entertainment

(d) At the end of vacations

(e) Beyond the scope of tests


## Q59. Which of the following should replace the highlighted phrase (D)?

(a) remain central to the classroom lecture delivery

(b) No replacement required

(c) hold perfect retention forever

(d) generate teacher guidance entirely

(e) support different learning styles


## Q60. Which of the following should replace the highlighted phrase (E)?

(a) Learners must depend on hints,

(b) One should copy model answers,

(c) Teachers will complete all tasks,

(d) Students should verify sources,

(e) No replacement required


## Q61. In the question below, few sentences have been given. Find out which of the following sentence is incorrect.

(A) The regulator issued clarifications that were awaited by lenders across multiple product categories for months.

(B) He suggested that the fees is waived to accommodate unexpected documentation errors in certain applications.


<!-- Page 9 -->

(C) Between you and me, the mock results reflect careless reading rather than difficult passages overall.

(D) Despite the rain warnings, attendance remained strong and proctors reported smooth conduct overall across centres.

(a) Only (B)

(b) Both (B) and (D)

(c) Only (A)

(d) Both (B) and (C)

(e) (A), (B), and (D)


## Q62. In the question below, few sentences have been given. Find out which of the following sentence is incorrect.

(A) Walking through the archive, the labels guided researchers toward previously misfiled securities disclosures yesterday effectively.

(B) The compliance team reviewed contracts, verified calculations, and logged deviations within the centralized tracker yesterday.

(C) She appears to have forgotten to submit reimbursement proofs before accounts closed yesterday for reconciliation.

(D) No sooner had the briefing ended then questions erupted regarding vendor eligibility criteria for onboarding.

(a) Only (D)

(b) Both (A) and (D)

(c) Only (C)

(d) Both (B) and (C)

(e) (A), (B), and (D)


## Q63. In the question below, few sentences have been given. Find out which of the following sentence is incorrect.

(A) The chair recommended that the minutes be circulated before voting on the amended resolution today.

(B) The applicants complied with documentary requirements specified in paragraph six of the guidance for onboarding.

(C) Our procedures differ than the regulator’s notices because internal risk thresholds are updated quarterly internally.

(D) Investigators found that several controls had failed before the alerting system was finally recalibrated internally.

(a) Only (B)

(b) Both (B) and (D)

(c) Only (C)

(d) Both (B) and (C)

(e) (A), (B), and (D)


## Q64. In the question below, few sentences have been given. Find out which of the following sentence is incorrect.

(A) He is one of those reviewers who insist on primary evidence before approving reimbursement claims.

(B) The manager, who was instructed to expedite the process, submitted the forms yesterday without delay.

(C) Twenty percent of the application are incomplete, according to the latest verification dashboard this morning.

(D) Had the documents been uploaded earlier, the refund would have processed without additional correspondence today.

(a) Only (D)

(b) Both (B) and (C)

(c) Only (A)

(d) Both (C) and (D)

(e) (A), (B), and (D)


## Q65. In the question below, two columns of phrases are provided—Column I and Column II. Choose the pair that, when joined with the given connector, forms a grammatically correct and contextually meaningful sentence. Column I Column II

A. The hall fell silent, D. ___ she would wake up before sunrise.

B. The instructions were printed clearly,

E. _____ even the last row could read them.

C. Ravi revised the rules again,

F. ______everyone could hear the speaker without strain.

(a) B-F (so)

(b) C-E (therefore)

(c) A-F (so that)

(d) B-D (within); A-F (for)

(e) B-E (but)


## Q66. In the question below, two columns of phrases are provided—Column I and Column II. Choose the pair that, when joined with the given connector, forms a grammatically correct and contextually meaningful sentence. Column I Column II

A. The bell rang twice, D. ___ the test would begin in five minutes.

B. Neha carried a spare pen,

E. ___ visitors could read it before entering.

C. The notice was posted at the entrance,

F. ___ her pen stopped working midway.

(a) A-D (in which)

(b) C-E (so that); B-F (in case)

(c) A-F (as a result)

(d) B-D (hence); A-F (for)

(e) B-E (lest)


## Q67. In Column I, the highlighted parts may be grammatically incorrect. Column II lists possible replacements. Choose the option that gives the correct combination so that the sentences become grammatically correct.


<!-- Page 10 -->

Column I Column II

A. Neither the rate nor the fees was discussed in detail.

D. is little

B. There is few evidence to support the revised projection.

E. were discussed

C. Unless the fields are complete, the system will not proceed.

F. are not complete

(a) A- no replacement required

(b) A-E

(c) A-E; B-D

(d) B-D

(e) C-F


## Q68. In Column I, the highlighted parts may be grammatically incorrect. Column II lists possible replacements. Choose the option that gives the correct combination so that the sentences become grammatically correct. Column I Column II

A. She often spend without checking the balance.

D. rarely spends

B. She not only did submit the claim, she also attached receipts.

E. The token had been

C. Had the token been issued earlier, the queue would have moved faster.

F. Not only did she

(a) A-D

(b) B-F; A-D

(c) A-E; B-D

(d) B-D

(e) C- No replacement required


## Q69. In the following question, a paragraph is given with few blanks. Choose the word from the given options that will fill all the blanks and make the paragraph grammatically correct and contextually meaningful. ____________ the bell rang, the committee came to order and asked Riya to ____________ the proceedings. What looked like a ____________ discrepancy in the figures soon turned serious, and the chair granted only a ____________ for each member to speak.

(a) record

(b) tiny

(c) time

(d) minute

(e) hour


## Q70. In the following question, a paragraph is given with few blanks. Choose the word from the given options that will fill all the blanks and make the paragraph grammatically correct and contextually meaningful. At daybreak, the ____________ was soft across the courtyard, and the usher asked us to ____________ the candles; with ____________ luggage we climbed the stairs, and the walls, painted a ____________ blue, calmed the room.

(a) light

(b)hope

(c) heavy

(d) sight

(e) mist


## Q71. In the following question, a paragraph is given with few blanks. Choose the word from the given options that will fill all the blanks and make the paragraph grammatically correct and contextually meaningful. At the quarterly review, the operations head proposed to ____________ the warehouses with fast -moving items before the festive rush; the audit flagged expired ____________ lying unsold; the service lead warned against giving ____________ replies to complaints; and the surge in the company’s ____________ cheered employees.

(a) stock

(b) supply

(c) standard

(d) share

(e) stuff


## Q72. In the following question, a paragraph is given with few blanks. Choose the word from the given options that will fill all the blanks and make the paragraph grammatically correct and contextually meaningful. During the annual meet, the secretary was asked to ____________ every decision accurately; finance reported a ____________ profit on the new line; HR checked the attendance ____________ before releasing bonuses; and legal cautioned that any breach would stay on an employee’s ____________.

(a) count

(b) file

(c) register

(d) log

(e) record


### Directions (73-75): Read the following passage carefully and answer the questions given below them. Video games have evolved into a multifaceted medium that offers both recreation and intellectual stimulation for students. When used judiciously, they can yield numerous cognitive and pedagogical benefits. Educational and strategy-based games enhance criti cal thinking, problem - solving aptitude, and spatial awareness, while also fostering collaborative and communicative skills through multiplayer formats. Furthermore, gaming can serve as a therapeutic escape, helping students alleviate stress and rejuvenate their minds after intense academic exertion. Studies even suggest that certain action-oriented games bolster reflexes, hand-eye coordination, and attentional focus, contributing to both mental agility and adaptive learning.


<!-- Page 11 -->

Despite these advantages, excessive indulgence in video games can have detrimental repercussions. Prolonged exposure often leads to addictive tendencies, causing students to neglect academic responsibilities and social interactions. Extended screen time ma y trigger visual fatigue, musculoskeletal strain, and disrupted circadian rhythms. Moreover, recurrent engagement with violent or aggressive content can desensitize young minds, fostering irritability and diminishing empathic sensitivity. Academic performance may deteriorate as students become engrossed in virtual worlds, and their overreliance on digital engagement can precipitate social alienation and emotional stagnation. In essence, video games represent a powerful yet ambivalent influence —capable of enriching the intellect when approached with moderation but equally capable of impairing growth when pursued obsessively. The key lies in equilibrium and discernment, ensuring that gaming remains a source of enrichment rather than erosion.


## Q73. Which of the following can most reasonably be inferred from the passage about students who engage in video gaming?

(a) Their physical well -being generally improves with extended hours of immersive gameplay.

(b) Their capacity for empathy and interpersonal understanding tends to strengthen with exposure to violent game content.

(c) Their ability to manage time effectively is largely unaffected by prolonged engagement in digital environments.

(d) Their academic motivation remains stable even when gaming becomes excessive and repetitive.

(e) Their cognitive growth may be positively influenced when gameplay is balanced with academic and social activities.


## Q74. Which of the following inferences can most plausibly be drawn from the passage concerning the adverse ramifications of excessive video -gaming behavior among students? (I) Prolonged immersion in virtual domains may engender affective desensitization and a diminution of empathic responsiveness. (II) Sustained exposure to screens is liable to induce physiological strain, including ocular exhaustion and postural discomfort. (III) Individuals who devote inordinate time to gaming typically offset scholastic disengagement through heightened interpersonal participation.

(a) Only (I)

(b) Only (II)

(c) Both (I) and (II)

(d) Both (II) and (III)

(e) All (I), (II), and (III)


## Q75. According to the passage, all of the following are identified as constructive outcomes of video gaming when practiced in moderation EXCEPT:

(a) The augmentation of analytical acuity and visuospatial intelligence through cognitively demanding gameplay.

(b) The reinforcement of cooperative aptitude and interpersonal articulation fostered by collaborative gaming formats.

(c) The refinement of psychomotor responsiveness and sustained attentional control through dynamic, action - based interaction.

(d) The amplification of empathic receptivity and affective discernment resulting from recurrent exposure to violent digital scenarios.

(e) The mitigation of psychological strain and restoration of cognitive vitality following rigorous academic endeavor.


### Directions (76–77): Find the pattern of the series and answer the question given below. Series A: 0.5, 3, 16, 97, P, 5441 Series B: Q, Q - 400, 3.5P+172, 2296, 2100, 1956


## Q76. Find the ratio of P to Q.

(a) 171: 820

(b) 170: 819

(c) 169: 821

(d) 168: 823

(e) None of these


## Q77. Find the value of √(P - 4).

(a) 24

(b) 26

(c) 23

(d) 25

(e) 21


## Q78. The side of a square is X cm, and the area of the square and the area of a rectangle are equal. If the length and breadth of the rectangle are (2X - 5) cm and (X – 6) cm, respectively, then find perimeter of the rectangle (in cm).

(a) 60

(b) 80

(c) 70

(d) 50

(e) 90


## Q79. Three equations are given below. Solve the equations and answer the question given below. A: x² + x – 6 = 0 B: y² + y -12 = 0 C: 2z² - 3z – 5 = 0 I: (2𝑥 + 3)𝑥 II: (22)𝑦 III: 12Z Find the relation between I, II and II. (Consider only positive roots of equations A, B and C.)

(a) I < II < III

(b) I > II > III

(c) I < II > III

(d) I < II ≥ III

(e) I = II > III


<!-- Page 12 -->


## Q80. Three equations are given below. Solve the equations and answer the question given below. I: x² - 12x + 35 = 0 II: y² + 3y -70 = 0 III: z² - 5z – 14 = 0 A: x = y > z B: x < y > z C: x < y The conditions (A, B, and C) are given, which have to be considered for the roots of each equation.

(a) y ≤ z, If only A follow

(b) (y + z)< x, If only A follows

(c) y ≤ z, If only C follow

(d) (y + z)< x, If only B follows

(e) All follows


## Q81. Find the pattern of the series and answer the question given below. Series: (K + 1), (2S − 2), (P² -19), 120(K +1), C Note: A: K = Square root of smallest two-digit perfect square. B: P = Second smallest two-digit prime number. C: S = Natural number, Maximum value of 2S < 40. Quantity I: 4 × 3rd term of the given series. Quantity II: C/3 Quantity III: K × S³ + 100.

(a) Quantity I > Quantity II > Quantity III

(b) Quantity I < Quantity II = Quantity III

(c) Quantity I = Quantity II = Quantity III

(d) Quantity I ≤ Quantity II < Quantity III

(e) Quantity I ≥ Quantity II = Quantity III


## Q82. A shopkeeper has three types of apples (A, B, and

C) with the following stock and individual weight. Type A: 50 apples in stock, 40 gm each. Type B: 40 apples in stock, 60 gm each. Type C: 60 apples in stock, 25 gm each. He selects a certain number of apples of each of the three types and places them into a crate K. The number of apples chosen for each type are consecutive multiples of 5. The number of C -type apples in K is the minimum among all. If the total weight of all the apples in the crate is 2050 gm, then how many type B apples did the shopkeeper put in the crate?

(a) 30

(b) 40

(c) 20

(d) 50

(e) 60


## Q83. A shopkeeper sells two items, A and B. The ratio of the cost price of A to B is 3:4, respectively, and the ratio of the selling price of A to B is 58:69, respectively. A discount of 20% and 10% is offered on items A and B, respectively. If the profit earned on item B is 3.5%, then find the profit percentage on item A.

(a) 16%

(b) 12%

(c) 15%

(d) 18%

(e) 10%


## Q84. I: 𝑥(𝑥−5)+20 𝑥 = 9 − 𝑥 II: y² + 2√17 y - 5² = √68 y

(a) If x > y

(b) If x ≥ y

(c) If x < y

(d) If x ≤ y

(e) If x = y or no relation can be established between x and y


## Q85. I: 𝑥 (2𝑥 + 𝑥 ) − 11𝑥 = 2𝑥 II: y² - 4² + 2²y = -2y

(a) If x > y

(b) If x ≥ y

(c) If x < y

(d) If x ≤ y

(e) If x = y or no relation can be established between x and y


### Direction ( 86-90): The graph given below shows the degree distribution of total number projects (private + public) handled in 4 quarters Q1, Q2, Q3 and Q 4. The table shows the percentage of private projects handled wrt projects handled in respective years.

Quarters Percentage of private projects handle wrt total project handled Q1 3a% Q2 35% Q3 50% Q4 a% Note: Measure of central angle of pie of pie (x° + y°) is not equal to 360° The value of x0= 21.6° more than y0 The difference between private and public projects handled in Q2 is 108.


## Q86. If the average of public project handle in Q1 and in Q3 is 150, then find the private project handle by Q1 is what percentage of total project handle by Q2.

(a) 120

(b) 50

(c) 100

(d) 60

(e) 70


<!-- Page 13 -->


## Q87. The ratio of private to public project handle in Q4 is 3:1, then find the difference between public project handle in Q4 and total project handle in Q1.

(a) 122

(b) 252

(c) 282

(d) 202

(e) 123


## Q88. Find the total project handle in the year.

(a) 1200

(b) 1500

(c) 1000

(d) 600

(e) 700


## Q89. If 60% total project handle are private projects, find the ratio of public project handle in Q1 and Q4 together to total project handled in Q2.

(a) 12:11

(b) 15:13

(c) 10:11

(d) 17:40

(e) 7:9


## Q90. If the value of a is 16.67%, then find the public project handled in Q1 and Q4.

(a) 322

(b) 348

(c) 382

(d) 302

(e) 323


### Direction ( 91-94): The table given below shows the cumulative number of ice creams (chocolate + vanilla) sold in given days. The second table shows the percentage of chocolate ice creams sold and the percentage of vanilla ice creams sold in the given day. Note: (i) a is the positive root of the equation P² + 16P - 465 = 0 (ii) b is the difference between the roots of the equation X²- 30X + 125 = 0 Days Total ice cream sold On Monday 450 Till Tuesday 1010 Till Wednesday 1390 Till Thursday 2010

Days Percentage of chocolate ice creams sold Percentage of vanilla ice cream sold Monday 4a Tuesday 4b-20 Wednesday a+b Thursday 3b+10


## Q91. The ice cream sold on Friday is average of ice cream sold on Wednesday and Thursday. Find the total ice cream sold on Friday is how many more than vanilla ice cream sold on Thursday.

(a) 66

(b) 77

(c) 88

(d) 99

(e) 121


## Q92. Selling price of each vanilla ice cream is 20% more than the chocolate ice cream. Find the ratio of amount received by selling chocolate ice cream to vanilla ice cream sold on Monday.

(a) 5:4

(b) 7:5

(c) 8:5

(d) 5:8

(e) 1:2


## Q93. Total chocolate ice cream sold on Tuesday is what percentage of vanilla ice cream sold on Thursday.

(a) 61

(b) 72

(c) 52

(d) 92

(e) 100


## Q94. If Y is the 50% of average chocolate ice cream sold on Tuesday and Thursday and ratio of Y and Z is 5:4, find the difference between Z and X.

(a) 57

(b) 77

(c) 88

(d) both option ‘a’ and ‘b’

(e) both option ‘b’ and ‘c’


### Directions (95-100): Read the following table carefully and answer the questions given below. The table given shows the profit earned by four companies in 2020 and 2021 and the difference between the profit earned in 2020 and 2021 by each company. Companies Profit in Profit in Difference between the profits in 2020 and P 3X 1600 400 Q 5X 1500 500 R 150% of X 350 250 S 900 550 87.5% of X Note: Value of X is an integer.


## Q95. The profit of company T in 2020 is equal to the sum of 20% of company P profit and 30% of company Q profit from the same year. From 2020 to 2021, the profit of company T increased by the same percentage as the profit of company P increased over the same period. Find the profit of company T in 2021.


<!-- Page 14 -->

(a) Rs 1020

(b) Rs 1120

(c) Rs 1420

(d) Rs 1560

(e) Rs 1440


## Q96. If the total revenue (selling price) of company T in 2020 is Rs 10000, then find the cost price (in Rs).

(a) 12000

(b) 8000

(c) 6000

(d) 7000

(e) 9000


## Q97. The cost price of company R in 2020 is Rs 2400. If company R’s item is marked at a price 50% above its cost price, then find the discount percentage.

(a) 6.67%

(b) 12.5%

(c) 16.67%

(d) 8.33%

(e) 10%


## Q98. The cost price of company S in 2021 is Rs A. The item was marked up by 50% above its cost price. If the discount offered is the same as 10% of the cost price of the item, then find the marked price of the item (in Rs).

(a) 2262.5

(b) 1062.5

(c) 2062.5

(d) 2026.5

(e) 2562.5


## Q99. The cost price of item of company P in 2020 is equal to its profit earned in the same year. The cost price of an item of company S in 2020 was equal to the profit earned in the same year. If company P offered a 25% discount on its marked price and company S offered a 20% discount, then find the ratio between the marked price of items of company P to that of company S.

(a) 64:45

(b) 61:26

(c) 60:49

(d) 63:35

(e) 45:64


## Q100. The cost price of item of company P in 2021 is Rs T, and the item was marked up by W% above its cost price. The selling price was 140% of the cost price, and the discount offered was the same as 50% of the total markup amount. Find W.

(a) 55

(b) 70

(c) 65

(d) 50

(e) 80


## Q101. Set A: The set contains six positive consecutive multiples of 5 (two-digit numbers). Set B: The set contains three positive consecutive multiples of 6 (two-digit numbers). Which of the combinations is definitely true? Column I Column I P. The difference between the smallest number of set A and set B is equal to the difference between the 3rd smallest number of set A and set B.

X. The second smallest number of set A is equal to the second smallest number of set B.

Q. One of the number in set B is 36. Y. Sum of the largest numbers of set A and set B is 146. R. The largest number of set A is greater than the largest number of set B.

(a) Only PX

(b) Both PX and RX

(c) Both PX and RY

(d) PY, RX ad QY

(e) None of these


## Q102. On a 300 km long racing track, three bikes — A, B, and C take part in a race. Initially, their speeds are 50 km/hr for Bike A, 40 km/hr for Bike B, and 60 km/hr for Bike C. After the first 2 hours of racing, their speeds are altered as follows: Bike A adopts a new speed which is 25% more than Bike C’s speed at that moment. Bike B increases its speed by 10% compared to its original speed. Bike C reduces its speed to 80% of Bike A’s original speed. Find the time gap (in minutes) between the bikes that finished first and second.

(a) 40 minutes

(b) 50 minutes

(c) 45 minutes

(d) 35 minutes

(e) 30 minutes


### Directions ( 103-106): Read the information carefully and answer the questions based on it. There are three schools, A, B, and C, with a total of 650 girls across all three. The ratio of the number of boys in School A to the number of girls in School B is 4:5. The number of girls in School A is 20% greater than the number of girls in School

B. In School C, the total num ber of students is 420, and the number of girls is 120 less than the number of boys in School

B.


<!-- Page 15 -->


## Q103. If total students in A are 400, then find the difference between total number of boys in school B and C?

(a) 150

(b) 160

(c) 180

(d) 120

(e) Can’t be determined


## Q104. Find the difference between girls in A & B together and number of boys in C?

(a) 310

(b) 320

(c) 230

(d) None of these

(e) Can’t be determined


## Q105. Find the ratio of total boys in A to total girls in C?

(a) 3:5

(b) 2:3

(c) 3:1

(d) 2:1

(e) Can’t be determined


## Q106. Find the ratio of sum of number of students in A and girls in B to total number of boys in A?

(a) 6: 5

(b) 15: 4

(c) 12: 5

(d) 5: 2

(e) Can’t be determined


## Q107. A shopkeeper sells two articles, A and B. The ratio of the cost price of A and B is 4:5, respectively. The marked price of A is thrice the marked price of B. The selling price of A is Rs 840, which is Rs 840 more than the discount offered on it. What is th e profit earned on B (in Rs)? I: The cost price of A is Rs 700, and the profit earned on B is 20% of its cost price. II: The selling price of A is Rs 665 more than the profit earned on B.

(a) Only I

(b) Only II

(c) Both I & II together

(d) Either I or II

(e) Neither I nor II


### Direction ( 108-110): The bar graph shows the total people consumed alcoholic beverage in three different cities. The line graph shows the number of people consumed non-alcoholic beverages in each city. Table shows the data of male and female consumed alcoholic and non - alcoholic beverage in each city.

Cities Alcoholic beverage Non-alcoholic beverage A Male consumed 200 more than that of female consumed Female consumed is 40 more than the male consumed B Male consumed is 66.66% of female consumed Female consumed is 50% more than male consumed C Females consumed is 28.57% less than the male consumed Male consumed is 50% of the female consumed


## Q108. Find the difference between males who consumed alcoholic beverages in C and female who consumed alcoholic beverages in B.

(a) 30

(b) 50

(c) 60

(d) 70

(e) 100


## Q109. Find the ratio of male consumed alcoholic beverage in A and B together to female consumed non- alcoholic beverages in C.

(a) 25:6

(b) 17:15

(c) 8:15

(d) 15:8

(e) 11:12


## Q110. The non- alcoholic beverage consumed in all the cities is what percentage of total people in all the cities.

(a) 61

(b) 42

(c) 32

(d) 112

(e) 12

A B C People consumed alcoholic beverage People consumed non alcoholic beverage


<!-- Page 16 -->

Solutions


### Directions (1-5): Sol.

S1. Ans.(d) Sol. Four persons sit between L and the one who faces X.

S2. Ans.(c) Sol. Fifth to the right

S3. Ans.(d) Sol. O sits opposite to E – is the true statement.

S4. Ans.(c) Sol. T sits opposite to the person who sits fourth to the right of H.

S5. Ans.(e) Sol. M is related to A. Logic here is - both the persons sit opposite to each other.


### Directions (6-10): Sol. Designations Persons States Sports Manager E Gujarat Badminton AM B Rajasthan Hockey SE D Tamil Nadu Basketball JE C Maharashtra Cricket TL F Uttar Pradesh Football HR Specialist A Haryana Tennis

S6. Ans.(d) Sol. D is designated as Senior Executive.

S7. Ans.(b) Sol. The person who likes tennis is from Haryana.

S8. Ans.(c) Sol. The person from Uttar Pradesh likes Football and is designated as TL.

S9. Ans.(c) Sol. ‘B – Assistant Manager – Hockey’ – is correct.

S10. Ans.(e) Sol. Two persons


### Directions (11-13):

S11. Ans.(a) Sol. From Statement I and II together: E sits third to the right of C.


<!-- Page 17 -->

S12. Ans.(c) Sol. From Statement II only: Box T is placed at the second position from the bottom. Boxes S R Q P T U

S13. Ans.(d) Sol. Data given in both statements I and II together are not sufficient to answer.

S14. Ans.(e) Sol. Meaningful word formed- DESPAIR 5th letter from left = A

S15. Ans.(d) Sol. Given number = 8472674634 1st operation = 7381583543 2nd operation = 1358875433 3rd odd number from right = 5, 3rd even number from left = 4 Required sum = 5+4 = 9


### Directions (16-20): Sol. Logic here is: Words: Words are picked in dictionary order in each step and are placed at extreme left end after interchanging the position of second and third letters of the words. Numbers: Numbers are picked in ascending order in each step and are placed at extreme right end after multiplying both the digits of the number.

Input: dive 54 lime 26 bark 19 frog 56 mist 74

Step I: brak dive 54 lime 26 frog 56 mist 74 9

Step II: dvie brak 54 lime frog 56 mist 74 9 12

Step III: forg dvie brak lime 56 mist 74 9 12 20

Step IV: lmie forg dvie brak mist 74 9 12 20 30

Step V: msit lmie forg dvie brak 9 12 20 30 28

S16. Ans.(d) S17. Ans.(a)

S18. Ans.(b) Sol. 9+12+30 = 51

S19. Ans.(e) S20. Ans.(c)


### Directions (21-25): Final Arrangement I (Circular):


<!-- Page 18 -->

Final Arrangement II (Linear):

S21. Ans.(d) Sol. The person who sits immediate left of T in the circular seating arrangement, is fourth to the right with respect to R in linear seating arrangement.

S22. Ans.(c) Sol. Four persons sit to the right of P in the linear seating arrangement.

S23. Ans.(c) Sol. The who sits opposite to R in the circular seating arrangement, sits immediate right of U in linear seating arrangement.

S24. Ans.(d) Sol. Two persons sit between O and P (in circular seating arrangement) and three persons sit between T and Q (in linear seating arrangement).

S25. Ans.(e) Sol. Two persons sit between U and P in linear seating arrangement – is the true statement.


### Directions (26-29): Sol. Logic here is: Digits: Total number of distinct consonants (repeated consonants counted only once) is taken. Symbols: If the number of letters present in the word is coded as symbols. 7 then it is coded as # 6 then it is coded as & 5 then it is coded as $ 4 then it is coded as @

S26. Ans.(a) Sol. The code for ‘blazing’ is #5

S27. Ans.(e) Sol. The code for ‘rolling waves’ is ‘#4 $3’

S28. Ans.(d) Sol. Noise- $2 - is correctly matched.

S29. Ans.(b) Sol. The code for ‘escape’ is &3.

S30. Ans.(d) Sol. Explanation:

I. Mentees showed significant improvement due to the guidance they received. This follows from the statement, as it clearly mentions that mentees improved their skills significantly after the mentorship program.

II. Senior employees always have the time to mentor junior employees effectively. This does not follow. The statement does not mention whether senior employees always have the time to mentor effectively, and assuming that would be incorrect.

III. Mentorship programs contribute to the growth of both mentees and mentors. This is supported by the statement, which mentions that mentors reported greater job satisfaction and a stronger sense of achievement, indicating mutual growth.

IV. Mentees would have improved even without the mentorship program. The statement does not provide any support for this assumption. The improvement is specifically attributed to the mentorship program.


<!-- Page 19 -->

S31. Ans.(a) Sol. Explanation: [a] is correct because the story attributes the 30% increase in retention and 15% sales increase due to the loyalty program. [b] is too general; not all loyalty programs are always effective. [c] is incorrect as the managers believe the loyalty program played a significant role. [d] is false; the program did have an effect. [e] is incorrect because other factors might have contributed too.

S32. Ans.(b) Sol. I and II are valid as assigning specific chores and creating a schedule will ensure tasks are completed on time and reduce confusion. III is not fully supported as a "fixed" schedule doesn't necessarily guarantee fair distribution unless specified.

S33. Ans.(b) Sol. The store realized that many customers had not been able to take advantage of the sale due to limited stock. Explanation: The sale was extended because customers couldn't buy their desired models due to limited stock, indicating the need to accommodate more demand. Additional Information: [a] & [c] are unrelated to the reason for extending the sale. [d] & [e] are not supported by the given statement.

S34. Ans.(b) Sol. Explanation: The HR department’s decision to extend the registration deadline and send reminder emails indicates that they believe some employees may not have registered earlier due to lack of awareness or time constraints. By giving an extended opportunity and remindi ng them again, HR assumes that more employees will be encouraged to participate, helping to reach the required count for the trip. Thus, option [b] is the most logical assumption behind the decision.

S35. Ans.(d) Sol. Explanation: Since many people are visiting temples and organizing family events, the need for flowers has naturally increased. To meet this growing demand and serve customers for longer hours, flower shops have extended their opening time. Hence, this option logically explains the situation.

S36. Ans.(e) Sol. Only II and III Brief Explanation: Flexible working hours and work-from-home options directly address the problems of long commutes and poor work-life balance in metro cities. The third statement is not necessary as smaller towns do not face similar traffic or commuting issues.


### Directions (37-40): Sol. The direction & distance of each person is shown by different colours. Albert – Black, John – Blue, Edison – Red, Nathon - Green

S37. Ans.(a) Sol. West


<!-- Page 20 -->

S38. Ans.(b) Sol. √160m

S39. Ans.(d) Sol. Only III is not true

S40. Ans.(b) Sol. Johns’s final position is to the north-east of Point E.

S41. Ans.(d) Sol. Theme: Impact of urbanization on wildlife and ecological responses. Why: • (a) Coherent. Urban sprawl causes habitat loss—direct effect of cities on animal life. • (b) Coherent. Noise from traffic/construction alters bird behavior—specific urban stressor on wildlife. • (c) Coherent. Green corridors are a mitigation strategy within urban planning to aid animal movement. • (d) Incoherent. Minimalist apartment design is an interior/architectural trend and does not address wildlife or ecological impact. • (e) Coherent. Urban-adapted species (e.g., raccoons, pigeons) exemplify how some animals thrive in city ecosystems.

S42. Ans.(b) Sol. Theme: Healthy eating and nutrition choices and their health effects. Why: • (a) Coherent. Fruits and vegetables supply key vitamins and minerals—directly about diet. • (b) Incoherent. Describes blood circulation; it’s human physiology, not nutrition. • (c) Coherent. Whole grains and fiber relate to digestion—diet-focused. • (d) Coherent. Replacing sugary drinks with water is a dietary choice affecting weight. • (e) Coherent. Processed food and risks like diabetes—health impacts of diet.

S43. Ans.(a) Sol. The correct answer is (a). Explanation: The original sentence: “ An empty plate is more than a sign of hunger. It reflects inequality, waste, and the failure to make food security a collective priority.” emphasizes that an empty plate symbolizes deeper social issues — inequality, waste, and a shared failure of responsibility, not just hunger. Option (a): “The image of an empty plate embodies not only human deprivation but the collective moral failure of societies that tolerate hunger amid abundance and structural inefficiency.” This perfectly mirrors the tone and meaning: • “Human deprivation” = hunger • “Collective moral failure” = failure to prioritize food security • “ Amid abundance and structural inefficiency” = inequality and waste It captures the moral and systemic dimensions implied in the original. Why others are incorrect: • (b) reduces it to individual hardship, ignoring the collective and systemic dimensions — opposite meaning. • (c) implies hunger and inequality have been largely eliminated, contradicting the original message. • (d) reframes it as personal choice, which distorts the moral-social message. • (e) suggests the symbol now means temporary scarcity, downplaying systemic inequality. Answer: (a)

S44. Ans.(d) Sol. The correct answer is (d). Explanation: The original sentence states: “Recent studies reveal that exposure to microscopic air pollutants does not merely affect the lungs. These tiny particles penetrate the bloodstream, elevating the risk of heart attacks and strokes.” This means:


<!-- Page 21 -->

• Microscopic air pollutants (fine particulate matter) • Enter the bloodstream (not confined to lungs) • Increase risk of cardiovascular diseases such as heart attacks and strokes Option (d): “Fine particulate pollutants enter the circulatory system and contribute significantly to cardiovascular complications, proving that air quality is directly linked to heart health.” This option accurately restates all the main ideas: • Mentions fine particulate pollutants (microscopic air pollutants) • Notes entry into the circulatory system (penetrate the bloodstream) • Describes cardiovascular complications (heart attacks and strokes) • Establishes a direct link between air quality and heart health Hence, it conveys the same idea and context. Why others are incorrect: • (a) Reverses the meaning — claims pollutants strengthen immunity and reduce disease → opposite of original. • (b) Says particles stay in the respiratory tract with no long-term effects → contradicts “penetrate the bloodstream.” • (c) Focuses on the nervous system rather than cardiovascular → irrelevant. • (e) Restricts impact to outdoor workers only → incorrect generalization. Answer: (d)

S45. Ans.(a) Sol. Final paragraph (BACD): Rainwater harvesting is a simple conservation method. It helps in storing water for future use. This collected water can be used for daily needs. This method is especially useful in drought-prone areas. Why BACD works: • B introduces the topic. • A follows naturally: “It” refers to rainwater harvesting and states the key benefit (storage). • C specifies an immediate application of the stored/collected water (daily needs). • D closes with the situational significance (drought-prone areas), giving the paragraph purpose and scope.

S46. Ans.(c) Sol. Explanation of options: • (a) Incorrect. The passage criticizes protectionism and “fortress mentality” for causing weak airlines, limited connectivity, and high fares. • (b) Incorrect. The author argues for regional cooperation and open skies across countries, not a narrow domestic focus. • (c) Correct. The conclusion urges “regional cooperation, deregulation, and accessibility,” i.e., liberalization/open skies for real progress. • (d) Incorrect. The text calls air travel a “luxury” for a few, with fares among the most expensive globally —so it is not affordable or thriving. • (e) Incorrect. The author does not call for banning foreign involvement; they want competition and liberalization, the opposite of exclusion.

S47. Ans.(b) Sol. Correct answer: (b) begets Why: • (a) facilitates — Correct in meaning (“makes easier/helps”). The sentence is awkward due to a missing subject, but the word itself is context-appropriate. • (b) begets — Incorrect in this context. “Beget” means “to cause/give rise to” and takes a direct object (A begets B). The passage says “pricing begets from…,” which is ungrammatical. It should be “pricing stems from/arises from/is caused by.” • (c) connectivity — Correct usage referring to route links and network access in aviation. • (d) unreachable — Correct usage meaning not attainable for most Africans. • (e) All are correct — Incorrect because (b) is not. S48. Ans.(d) Sol. Option analysis: • (A) False. The passage states Lagos–Nairobi can exceed $2000, not less than $500. • (B) False. It says intra-African flights are often more expensive than flying to Europe. • (C) True. The passage explicitly mentions a round-trip between Lagos and Nairobi can exceed $2000.

S49. Ans.(e)


<!-- Page 22 -->

Sol. Correct answer: (e) To begin or launch successfully after preparation Option analysis: • (a) Incorrect. That describes a brief hype cycle, not the idiom’s meaning. • (b) Incorrect. “Fail to launch” is the opposite of “get off the ground.” • (c) Incorrect. This suggests eventual success after failure; the idiom is about the initial successful start. • (d) Incorrect. Remaining stuck in planning contradicts “getting off the ground.” • (e) Correct. “Got off the ground” means the project/initiative started and began operating successfully.

S50. Ans.(b) Sol. Correct answer: (b) Both (I) and (III) Option-by-option: • (I) Correct. The Yamoussoukro Decision (1999) aimed to liberalize/open African airspace to foster competition—exactly what the passage notes. • (II) Incorrect. The passage says implementation of SAATM has been sluggish and only a handful of countries have acted, not “successfully across all nations.” • (III) Correct. The passage states that limited competition keeps prices high, resulting in weak connectivity within Africa.

S51. Ans.(e) Sol. Correct answer: (e) Why: • (e) Matches the passage’s idea: air travel appears alluring but remains out of reach for most Afric Ans.(“fairytown fantasy… unreachable in practice”). • (a) Incorrect. No mention of fictional branding/marketing. • (b) Incorrect. The problem cited is protectionism and weak competition, not total foreign control. • (c) Incorrect. Airports are not said to operate only luxury tourist flights. • (d) Incorrect. Countries signed the Yamoussoukro Decision/SAATM; the issue is slow implementation, not refusal.

S52. Ans.(b) Sol. Correct answer: (b) Option analysis: • (a) Incorrect. “Collaborative” and “alliances” contradict the passage’s criticism. The text attacks protectionism, not cooperation. • (b) Correct. “Fortress mentality” refers to isolationist, protectionist policies that shield national carriers from outside competition, leading to weak airlines, poor connectivity, and high fares. • (c) Incorrect. The phrase is about market isolation, not investing in infrastructure. • (d) Incorrect. Expanding into foreign markets is outward-looking; the passage describes inward-looking protectionism. • (e) Incorrect. Cybersecurity is unrelated to the context of market access and competition.

S53. Ans.(d) Sol. Option analysis: • (a) Incorrect. The passage argues the opposite: competition is lacking, and that absence keeps prices high; it does not mention overcapacity or unfair pricing caused by too much competition. • (b) Incorrect. Pricing is directly linked to competition; without open skies and real competition, fares remain high. • (c) Incorrect. There is no claim that low competition keeps prices low; in fact, prices are high due to limited competition. • (d) Correct. The text states that protectionism limits competition, which in turn sustains high fares and weak connectivity. • (e) Incorrect. The passage never claims that foreign competition would reduce quality or safety; it advocates liberalization to improve outcomes.

S54. Ans.(b) Sol. Statement check: • (I) True. The passage says fewer than 2% of Africans fly regularly. • (II) False. It states intra-African flights are among the most expensive and can cost more than flying to Europe. • (III) True. The passage notes travelers often transit through cities like Paris, Istanbul, or Dubai to reach neighboring African countries.

S55. Ans.(d)


<!-- Page 23 -->

Sol. Option analysis:

(a) Incorrect. The passage does not link protectionism to better safety or higher aviation employment; instead, it critiques the outcomes as negative for the market.

(b) Incorrect. There is no claim that restricting foreign airlines accelerates infrastructure development.

(c) Incorrect. The text shows the opposite: with fewer competitors, fares stay high and demand remains suppressed.

(d) Correct. The passage states that bans meant to protect national carriers resulted in weak airlines, limited connectivity, and high fares due to reduced competition.

(e) Incorrect. Protectionism hinders, rather than helps, broader partnerships; the passage argues for liberalization and regional cooperation, not isolation.

S56. Ans.(b) Sol. Correct answer: (b) by putting instant Why: • The sentence needs two parallel “by + -ing” actions: “by expanding course catalogs online” and “by putting instant, reliable help at their fingertips.” • (a) “with round-the-clock tools in use” breaks parallelism and sounds clunky. • (c) “in the new digital climate” is a setting, not an action parallel to “expanding.” • (d) No replacement required leaves the sentence incomplete after “online,” lacking a grammatically parallel second action. • (e) “alongside evolving classroom policies” is unrelated to the immediate action and disrupts meaning.

S57. Ans.(c) Sol. Correct answer: (c) doubts that once waited Why: • The intended meaning is that learners’ doubts, which earlier had to wait until the next class, can now be cleared quickly with AI. “Doubts that once waited for the next class are resolved in minutes” is natural and precise. • (a) schedules that used to slip — Irrelevant to clearing queries. • (b) messages that often delayed replies — Awkward and off-focus; the subject is learners’ doubts, not messaging delays. • (d) forms that remained pending — Administrative, not learning-related. • (e) No replacement required — The original “clarities long resolved” is unidiomatic and incorrect.

S58. Ans.(a) Sol. Correct answer: (a) For exam preparation Why: • (a) Fits contextually: timed quizzes, error analysis, and revision plans are exam-prep activities. The fronted phrase sets the scenario smoothly—“For exam preparation, AI creates…”. • (b) If unchanged, “In the traditional classroom” clashes with the AI -driven, platform -based actions and weakens coherence. • (c) “During leisure entertainment” is irrelevant to quizzes and syllabus-aligned revision. • (d) “ At the end of vacations” is an arbitrary time marker with no contextual link. • (e) “Beyond the scope of tests” contradicts the focus on quizzes and syllabus alignment.

S59. Ans.(e) Sol. Correct answer: (e) support different learning styles Why: • The intended idea: “Visual summaries, flashcards, and audio notes … support different learning styles and busy schedules.” This is idiomatic and matches the examples given (visual, textual, auditory). • (a) “remain central to the classroom lecture delivery” mismatches the list (these tools aid self-study beyond lectures). • (b) No replacement required leaves “capture transforming information,” which is ungrammatical and unclear. • (c) “hold perfect retention forever” is hyperbolic and unnatural. • (d) “generate teacher guidance entirely” overstates AI’s role and doesn’t fit with the listed study aids.

S60. Ans.(d) Sol. Correct answer: (d) Students should verify sources Why: • (d) Fits the intended guidance: “verify sources, compare multiple explanations, and practice solving without prompts” — a coherent list of responsible-study actions.

• (a) “depend on hints” contradicts “practice without prompts.”


<!-- Page 24 -->

• (b) “copy model answers” promotes misuse and clashes with independent practice. • (c) “Teachers will complete all tasks” is irrelevant and passive. • (e) The original is ungrammatical and incomplete; replacement is required.

S61. Ans.(a) Sol. Correct answer: (a) Only (B) Why: • (A) Correct. Grammatically sound and clear. • (B) Incorrect. Two issues: 1. Subject–verb: “fees is” should be “fee is” or “fees are.” 2. Subjunctive/tense after “suggested that”: Prefer “the fee be waived” or “should be waived.” Acceptable fixes: • “He suggested that the fee be waived to accommodate unexpected documentation errors in certain applications.” • “He suggested that the fees be waived…” (if plural). • (C) Correct. “Between you and me” is the right case; agreement and structure are fine. • (D) Correct. Structure and agreement are fine; phrasing is natural.

S62. Ans.(b) Sol. Correct answer: (b) Both (A) and (D) Option-wise analysis: • (A) Incorrect. Dangling modifier: “Walking through the archive” should modify the researchers, but the grammatical subject is “the labels.” Also, adverb placement is clumsy (“yesterday effectively”). Better: “Walking through the archive, the researchers were guided by the labels toward previously misfiled securities disclosures.” • (B) Correct. Clear parallelism (“reviewed… verified… logged”) and natural placement of “yesterday.” • (C) Correct. “appears to have forgotten to submit… before accounts closed yesterday” is grammatical; “reimbursement proofs” is acceptable usage, and “for reconciliation” is a valid purpose phrase. • (D) Incorrect. The correlative pair is “No sooner… than,” not “then.” Correct: “No sooner had the briefing ended than questions erupted…”

S63. Ans.(c) Sol. Correct answer: (c) Only (C) Why (C) is incorrect: • Use “differ from, ” not “differ than.” Correct: “Our procedures differ from the regulator’s notices because internal risk thresholds are updated quarterly.” • Also, “internally” is redundant with “internal risk thresholds,” so it can be omitted. Why the others are acceptable: • (A) Subjunctive “be circulated” after “recommended” is correct; time marker “today” is fine. • (B) Structure and prepositions are correct: “complied with” + “requirements specified in paragraph six…” • (D) Tense sequencing is correct: past perfect (“had failed”) before simple past (“was… recalibrated”). “Internally” is optional but not wrong.

S64. Ans.(d) Sol. Correct answer: (d) Both (C) and (D) Why: • (C) Error in number agreement: “Twenty percent of the application are…” should be plural noun with plural verb. Correct: “Twenty percent of the applications are incomplete…” • (D) Wrong verb form and voice: “the refund would have processed” is unidiomatic; use passive perfect conditional. Correct: “Had the documents been uploaded earlier, the refund would have been processed without additional correspondence today.” Notes on the others: • (A) Correct: “one of those reviewers who insist…” takes plural “insist” because it refers to “reviewers.” • (B) Correct: punctuation and tense are fine.

S65. Ans.(c) Sol. Correct answer: (c) A–F (so that) Why: • A–F: “The hall fell silent, so that everyone could hear the speaker without strain.” Grammatically sound and contextually logical (purpose/result).


<!-- Page 25 -->

• (a) B –F with “so”: “The instructions were printed clearly, so everyone could hear the speaker…” Mismatch of ideas (instructions vs hearing). • (b) C–E with “therefore”: “Ravi revised the rules again, therefore even the last row could read them.” Awkward causation; revising rules doesn’t affect legibility. • (d) B–D (within); A–F (for): Not a valid single pairing; also “within/for” don’t fit D or F properly. • (e) B–E with “but”: “but” shows contrast; here both clauses are positive and should use a result/purpose connector, not contrast.

S66. Ans.(b) Sol. Correct answer: (b) C–E (so that); B–F (in case) Why: • C–E with “so that”: “The notice was posted at the entrance, so that visitors could read it before entering.” Purpose is expressed correctly. • B–F with “in case”: “Neha carried a spare pen, in case her pen stopped working midway.” Preventive action fits “in case.” Why the others don’t work: • (a) A–D with “in which”: “The bell rang twice, in which the test would begin in five minutes” is ungrammatical; “in which” cannot link these ideas. • (c) A–F with “as a result” is illogical (bell ringing doesn’t cause a pen to fail). • (d) B–D with “hence” and A–F with “for” both mispair cause-effect and purpose. • (e) B–E with “lest” is semantically wrong; “lest” expresses prevention of a negative outcome, not a positive purpose.

S67. Ans.(c) Sol. A: “Neither the rate nor the fees was discussed…” → With “neither…nor,” the verb agrees with the nearer subject. “fees” is plural, so use “were discussed.” Hence A–E. B: “There is few evidence…” → “evidence” is uncountable, so use “little,” not “few.” “There is little evidence …” is correct. Hence B–D. C: “Unless the fields are complete, the system will not proceed.” → Correct as written. Replacing with F (“are not complete”) creates a double negative with “unless” and flips the meaning, so C–F is wrong.

S68. Ans.(b) Sol. A → D: “She often spend …” needs third-person-singular agreement: “spends.” Replacing the highlighted part with “spends” fixes the verb; D (“rarely spends”) supplies a correct verb form. Note: the adverb changes the meaning (often → rarely), but in such replacement items grammar takes priority over adverbial choice. • B → F: Place “not only” before the auxiliary with inversion: “Not only did she submit the claim, she also attached receipts.” Hence B–F. • C: “Had the token been issued earlier, the queue would have moved faster.” is already correct (inverted third conditional). Replacing with E (“The token had been…”) would break the conditional/inversion. Why others are wrong • (a) Misses the required inversion in B. • (c) A–E is ungrammatical in context; B–D mismatches meaning and leaves inversion unresolved. • (d) B–D maps the wrong fix to B; it still lacks inversion. • (e) Ignores the necessary correction in B and the verb agreement in A.

S69. Ans.(d) Sol. Correct answer: (d) minute How it fits all blanks: • “the minute the bell rang” = as soon as the bell rang. • “asked Riya to minute the proceedings” = to record/prepare the minutes. • “a minute discrepancy” = very small. • “granted only a minute for each member to speak” = one minute. Why others don’t work: • (a) record: works for proceedings only; not for the other blanks. • (b) tiny: works for “discrepancy” but not the others. • (c) time: awkward in “the time the bell rang” (needs “by the time/at the time”) and doesn’t fit “to time the proceedings.” • (e) hour: fits only the last blank.


<!-- Page 26 -->

S70. Ans.(a) Sol. Correct answer: (a) light How it fits all blanks: • “the light was soft across the courtyard” — natural collocation. • “asked us to light the candles” — correct verb usage. • “with light luggage we climbed the stairs” — means not heavy. • “painted a light blue” — common color description. Why others don’t work: • (b) hope — Doesn’t collocate with candles/luggage/color. • (c) heavy — Cannot take “heavy the candles”; “heavy blue” is odd. • (d) sight — “sight the candles” is incorrect; “sight blue” is wrong. • (e) mist — “mist the candles” is incorrect; “mist luggage” and “mist blue” are wrong.

S71. Ans.(a) Sol. Correct answer: (a) stock Why it fits all blanks: • “stock the warehouses” = fill with goods. • “expired stock” = unsold inventory past date. • “stock replies” = canned/prepared responses. • “surge in the company’s stock” = share price rising. Why others don’t work: • (b) supply: “supply the warehouses” works, but “expired supply,” “supply replies,” and “company’s supply” don’t. • (c) standard: Doesn’t fit warehouses or inventory; “standard replies” is possible, but the other blanks fail. • (d) share: “share the warehouses” is wrong; only the last blank would fit. • (e) stuff: Informal; “expired stuff” and “company’s stuff” are inappropriate.

S72. Ans.(e) Sol. Correct answer: (e) record Why (record) fits all blanks: • “asked to record every decision accurately” — natural verb collocation. • “reported a record profit” — idiomatic for highest-ever profit. • “checked the attendance record” — standard phrase for attendance history. • “would stay on an employee’s record” — common expression for documented history. Why others don’t fit all: • (a) count — doesn’t suit profit/attendance/employee history. • (b) file — “file every decision” is odd; “file profit” is incorrect. • (c) register — verb works in (1), but “register profit” and “employee’s register” are unnatural; noun form “attendance register” works regionally but breaks others. • (d) log — works for (1) and (3), but “log profit” and “employee’s log” are not idiomatic for (2) and (4).

S73. Ans.(e) Sol. The correct answer is:

(e) Their cognitive growth may be positively influenced when gameplay is balanced with academic and social activities. Explanation: The passage emphasizes the dual nature of video games — they can be both beneficial and harmful depending on how they are used. • In paragraph 1, the author highlights that when used judiciously, games can enhance critical thinking, problem- solving, reflexes, attention, and even communication skills. • However, in paragraph 2, the author warns that excessive indulgence can lead to addiction, academic neglect, social isolation, and emotional stagnation. • Finally, the conclusion clearly states that video games are a powerful yet ambivalent influence and that the key lies in equilibrium and discernment. Hence, the passage implies that students’ cognitive and emotional development benefits most when gaming is balanced with other aspects of life, aligning directly with option (e).


<!-- Page 27 -->

Why the other options are incorrect: • (a) The passage states the opposite — extended hours cause musculoskeletal strain and visual fatigue, harming physical well-being. • (b) Exposure to violent content diminishes empathy and fosters irritability, not the opposite. • (c) Excessive gaming causes students to neglect responsibilities and lose time-management control. • (d) Academic performance deteriorates when gaming becomes excessive, so motivation doesn’t remain stable. Thus, only option (e) is consistent with the author’s viewpoint.

S74. Ans.(c) Sol. The correct answer is:

(c) Both (I) and (II) Explanation: The second paragraph of the passage explicitly describes the negative consequences of excessive gaming: “Prolonged exposure often leads to addictive tendencies, causing students to neglect academic responsibilities and social interactions. Extended screen time may trigger visual fatigue, musculoskeletal strain, and disrupted circadian rhythms. Moreover, recurrent engagement with violent or aggressive content can desensitize young minds, fostering irritability and diminishing empathic sensitivity.” From this, we can infer the following: • Statement (I): • Correct. The passage clearly mentions that repeated exposure to violent content desensitizes young minds and diminishes empathic sensitivity. This aligns perfectly with the idea of affective desensitization and reduced empathy. • Statement (II): • Correct. The text refers to visual fatigue (ocular exhaustion) and musculoskeletal strain (postural discomfort) as physical effects of prolonged screen exposure. • Statement (III): • Incorrect. The passage states the opposite — that excessive gaming leads to neglect of academic and social interactions and even social alienation, not increased interpersonal participation. Conclusion: Hence, only (I) and (II) can be logically inferred from the passage. Answer: (c) Both (I) and (II)

S75. Ans.(d) Sol. The correct answer is:

(d) The amplification of empathic receptivity and affective discernment resulting from recurrent exposure to violent digital scenarios. Explanation: The first paragraph of the passage lists several constructive benefits of video gaming when practiced in moderation: “Educational and strategy-based games enhance critical thinking, problem -solving aptitude, and spatial awareness, while also fostering collaborative and communicative skills through multiplayer formats. Furthermore, gaming can serve as a therapeutic escape, helping students alleviate stress and rejuvenate their minds after intense academic exertion. Studies even suggest that certain action-oriented games bolster reflexes, hand-eye coordination, and attentional focus… ” From this, we can match each correct point: • (a) Mentioned — “enhance critical thinking, problem -solving aptitude, and spatial awareness” = analytical and visuospatial improvement. • (b) Mentioned — “fostering collaborative and communicative skills through multiplayer formats” = cooperative and interpersonal enhancement. • (c) Mentioned — “action-oriented games bolster reflexes, hand-eye coordination, and attentional focus” = psychomotor and attentional development. • (e) Mentioned — “helping students alleviate stress and rejuvenate their minds” = reduction of psychological strain and cognitive refreshment. However: • (d) The passage states the opposite: “Recurrent engagement with violent or aggressive content can desensitize young minds, fostering irritability and diminishing empathic sensitivity.” So, rather than amplifying empathy, violent gaming reduces empathic responsiveness.


<!-- Page 28 -->

Conclusion: The only option not supported — and directly contradicted — by the passage is:(d)

Sol. (76-77) The pattern of the series A:

The pattern of the series B: Q, Q - 400, 3.5P+172, 2296, 2100, 1956

Q – 400 – 324 = 2552 Q = 3276

S76. Ans.(b) Sol. Required ratio = 680: 3276 = 170: 819

S77. Ans.(b) Sol. Required value = √(P - 4) = √(680 - 4) = √676 = 26

S78. Ans.(d) Sol. ATQ, X² = (2X - 5) (X – 6) X² = 2X² - 12X - 5X + 30 X² - 17X + 30 = 0 X² - 12X – 5X + 30 = 0 X = 12, 5 If X = 5 Breadth of the rectangle = 5 – 6 = -1 cm (can’t possible) So, X = 12 Length of the rectangle = 2X – 5 = 2(12) – 5 = 19 cm Breadth of the rectangle = X – 6 = 12 – 6 = 6 cm Required perimeter = 2(19 + 6) = 50 cm

S79. Ans.(c) Sol. A: x² + x – 6 = 0 x² + 3x - 2x – 6 = 0 x = -3, 2 x = 2 B: y² + y -12 = 0 y² + 4y – 3y -12 = 0 y = -4, 3 y =3 C: 2z² - 3z – 5 = 0 2z² - 5z + 2z – 5 = 0 z = 2.5, -1 z = 2.5 I: (2𝑥 + 3)𝑥 (2(2) + 3)𝑥 = 49


<!-- Page 29 -->

II: (22)𝑦 (22)3 = 64 III: 12Z 12(2.5) = 30 So, I < II > III

S80. Ans.(b) Sol. I: x² - 12x + 35 = 0 x² - 7x – 5x + 35 = 0 x = 7, 5 II: y² + 3y -70 = 0 y² + 10y - 7y -70 = 0 y = -10, 7 III: z² - 5z – 14 = 0 z² - 7z + 2z – 14 = 0 z = 7, -2 Correct Option (b) (y + z)< x, If only A follows A: x = y > z x (7) = y (7) > z (-2)

S81. Ans.(c) Sol. Smallest two-digit perfect square = 16 Square root of smallest two-digit perfect square = 4 K = 4 Second smallest two-digit prime number = 13 P = 13 Natural number, Maximum value of 2S < 40 25 < 40 32 < 40 S = 5 Series = (4+ 1), (25 − 2), (13² -19), 120(4 +1), C Series = 5, 30, 150, 600, C The pattern of the series:

C = 600 × 3 C = 1800 Quantity I: 4 × 3rd term of the given series. = 4 × 150 = 600 Quantity II: C/3 = 1800/3 = 600 Quantity III: K × S³ + 100. = 4 × 5³ + 100 = 600 So, Quantity I = Quantity II = Quantity III

S82. Ans.(c) Sol. The number of apples chosen for each type are consecutive multiples of 5. 5x, 5(x+1) and 5 (x+2) C-type apples in K is the minimum among all C-type apples = 5x


<!-- Page 30 -->

There are two possible cases Case I A-type apples are maximum A-type apples = 5 (x+2) B-type apples = 5(x+1) C-type apples = 5x Casel II B-type apples are maximum B-type apples = 5 (x+2) A-type apples = 5(x+1) C-type apples = 5x We take Case I Total weight = 40 × 5(𝑥 + 2) + 60 × 5(𝑥 + 1) + 25 × 5𝑥 = 200x + 400 + 300x + 300 + 125x = 625x + 700 ATQ, 2050 = 625x + 700 1350 = 625x x = 2.16 2.16 is not integer B-type apples = 5 (2.16+1) = 15.8 x ≠ 2.16 We take Case II Total weight = 60 × 5(𝑥 + 2) + 40 × 5(𝑥 + 1) + 25 × 5𝑥 = 300x + 600 + 200x + 200 + 125x = 625x + 800 ATQ, 2050 = 625x + 800 1250 = 625x x = 2 Type B apples = 5(x+2) = 5(2+2) = 20

S83. Ans.(a) Sol. Let the cost price of items A and B be 300x and 400x respectively. Selling price of item B = 400𝑥 × 100+3.5 100 = 414𝑥 Selling price of item A = 414𝑥 × 69 = 348𝑥 Profit on item A = 348x – 300 = 48x Required profit = 48𝑥 300𝑥 × 100 = 16%

S84. Ans.(e) Sol. I: 𝑥(𝑥−5)+20 𝑥 = 9 − 𝑥 x² - 5x + 20 = 9x - x² 2x² - 14x + 20 = 0 x² - 7x + 10 = 0 x² - 2x – 5x + 10 = 0 x = 2, 5 II: y² + 2√17 y - 5² = √68 y y² + 2√17 y - 5² = 2√17 y y² = 25 y = 5, -5 So, no relation can be established between x and y


<!-- Page 31 -->

S85. Ans.(e) Sol. I: 𝑥 (2𝑥 + 𝑥 ) − 11𝑥 = 2𝑥 2𝑥2 + 15 − 11𝑥 = 2𝑥 2𝑥2 − 13𝑥 + 15 = 0 2𝑥2 − 10𝑥 − 3𝑥 + 15 = 0 2x(x - 5) - 3(x – 5) = 0 (2x – 3) (x – 5) = 0 x = 3/2, 5 II: y² - 4² + 2²y = -2y y² - 16 + 4y + 2y = 0 y² + 6y – 16 = 0 y² + 8y - 2y – 16 = 0 y(y + 8) - 2(y + 8) = 0 (y + 8) (y – 2) = 0 y = -8, 2 So, no relation can be established between x and y Sol (86-90) 100.80+1080 +x0 + y0 = 360 x0 + y0 = 151.20 x0 = 21.60 + y0 solve above two equation 129.6 = 2 y0 64.80 (18%)= y0 = Q4 x0 = 86.40 (24%) = Q3 Q1 = 100.80 =28% Q2 = 1080 =30% ATQ, Let the total project in Q2= 100m 65m – 35m = 108 30m= 108 100m = 360 Q2 = 1080 =30% = 360 100% = 30 × 100 = 1200 Total project in all the quarter = 1200 Quarters Total project Private project Public project Q1 336 Q2 360 126 234 Q3 288 144 144 Q4 216

S86. Ans.(b) Sol. Public project handle in Q1 = 150 x 2 – 144 = 156 Private project handle in Q1 = 336 – 156 = 180 Required answer = 360 × 100 = 50%

S87. Ans.(c) Sol. Required diff = 336 – 54 = 282

S88. Ans.(a) Sol. Total project = 1200


<!-- Page 32 -->

S89. Ans.(d) Sol. Total project = 1200 Total public project = 40% of 1200 = 480 Public project handle in Q1 and Q4 together = 102 Required answer = 102:360 = 51:120 = 17:40

S90. Ans.(b) Sol. 16.67% = 1/6 So, in Q1 = 3a% = 50% 336 x 50% = 168 In q4 = a% = 1/6 Private project handle = 216 x 1/6 = 36 Public project handle = 216 – 36 = 180 Required answer = 168 + 180 = 348 Sol (91-94) P² + 16P - 465 = 0 (P+31)(P-15)= 0 15, -31 = P So, a = 15 X²-30X + 125 = 0 (X-25)(X-5)=0 X = 25 and 5 25 -5= 20= b Days Total ice cream sold Chocolate ice creams sold Vanilla ice cream sold Monday 450 270 180 Tuesday 1010-450 = 560 224 336 Wednesday 1390 -1010 = 380 133 247 Thursday 2010 – 1390 = 620 186 434

S91. Ans.(a) Sol. Ice cream sold on Friday = 380+620 2 = 500 Required answer = 500 – 434 = 66

S92. Ans.(a) Sol. Let the cost of vanilla ice cream be 120x The cost of chocolate ice cream be 100x Required answer = 270×100𝑥 180×120𝑥 =

S93. Ans.(c) Sol. Required percentage = 434 × 100 = 52%

S94. Ans.(d) Sol. Y = 50% of (224 +186/2)=102.5 Z = 5 × 102.5 = 82 Z – X = 82 – 5 = 77 or Z – X = 82 – 25 = 57


<!-- Page 33 -->

Sol. (95-100) For S 900 – 550 = 87.5% of X 350 = 87.5 100 × 𝑋 400 = X Companies Profit in 2020 Profit in 2021 Difference between the profits in 2020 and 2021 P 1200 1600 400 Q 2000 1500 500 R 600 350 250 S 900 550 350

S95. Ans.(b) Sol. The profit of company T in 2020 = 100 × 1200 + 100 × 2000 = 240 + 600 = Rs 840 Company P profit increment = 1600−1200 1200 × 100 = 33.33% Required answer = 840 × 3 = Rs 1120 (33.33% = 1/3)

S96. Ans.(b) Sol. Required profit = 10000 – 2000 = Rs 8000

S97. Ans.(c) Sol. Cost price = Rs 2400 Selling price = 2400 + 600 = Rs 3000 Marked price = 2400 × 100 = Rs 3600 Discount offered = 3600−3000 3600 × 100 = 16.67%

S98. Ans.(c) Sol. Cost price = Rs A Selling price = Rs (A + 550) Marked price = 𝐴 × 100 = 1.5𝐴 Rs Discount = 𝐴 × 100 = 0.1𝐴 Rs ATQ, 1.5A – 0.1A = A + 550 1.4A = A + 550 0.4A = 550 A = 1375 Marked price = 1.5(1375) = Rs 2062.5

S99. Ans.(a) Sol. The cost price of item of company P in 2020 = Rs 1200 The selling price of item of company P in 2020 = 1200 +1200 = Rs 2400 The cost price of item of company S in 2020 = Rs 900 The selling price of item of company S in 2020 = 900 + 900 = Rs 1800 The marked price of item of company P in 2020 = 2400 × 75 = Rs 3220 The marked price of item of company S in 2020 = 1800 × 80 = Rs 2250 Required ratio = 3200: 2250 = 64:45


<!-- Page 34 -->

S100. Ans.(e) Sol. Cost price = Rs T Selling price = Rs (T + 1600) Given, T + 1600 = 100 × 𝑇 T + 1600 = 1.4T 1600 = 0.4T 4000 = T Cost price = Rs 4000 Selling price = Rs 5600 Marked price = 4000 × 100+𝑊 100 = 4000 + 40𝑊 Markup price = 4000 + 40W – 4000 = 40W Discount = 40W/2 = 20W Selling price = 4000 + 40W – 20W ATQ, 4000 + 40W – 20W = 5600 20W = 1600 W = 80

S101. Ans.(b) Sol. X: The second smallest number of set A = The second smallest number of set B. Possible values = 30, 60 and 90. Take 30 Set A: 25, 30, 35, 40, 45, 50 Set B: 24, 30, 36 Take 60 Set A: 55, 60, 65, 70, 75, 80 Set B: 54, 60, 66 Take 90 Set A: 85, 90, 95, 100, 105, 110 Set B: 84, 90, 96 Set A = Two-digit number So, can’t takes 90 P: The difference between the smallest number of set A and set B is equal to the difference between the 3rd smallest number of set A and set B. We take PX The difference between the smallest number of set A and set B = 55 – 54 = 1 or 25 – 24 = 1 The difference between the 3rd smallest number of set A and set B = 36 – 35 =1 or 66 – 65 = 1 It is true. Q: One of the number in set B is 36. We take RX Take 60 Set A: 55, 60, 65, 70, 75, 80 Set B: 54, 60, 66 It is false. R: The largest number of set A is greater than the largest number of set B. We take RX 50 > 36 and 80 > 66 it is true. Y: Sum of the largest numbers of set A and set B is 146. We take PY and QY So many possibilities there The combinations are definitely true is PX and RX.


<!-- Page 35 -->

S102. Ans.(e) Sol. In 2 hours, total distance covered by bike A = 2×50 = 100 km Total distance covered by bike B = 2×40= 80 km Total distance covered by buke C = 2×60 = 120 After 2 hours, now the speeds Speed of bike B = 40 × 100 = 44 km/hr Speed of bike C = 50 × 100 = 40 km/hr And, speed of bike A = 40 × 100 = 50 km/hr Now the time taken by bike to cover remaining distance Time taken by bike A = 300−100 50 = 50 = 4 hours Time taken by bike B = 300−80 44 = 5 hours Time taken by bike C = 300−120 40 = 40 = 4.5 hours Total time taken by each bike to cover 300 km Time taken by bike A = 2+4 = 6 hours Time taken by bike B = 2+5= 7 hours Time taken by bike C = 2+4.5 = 6.5 hours We know which two bikes taken least time cover 300 km reached first and second So, A and C taken least time respectively to cover 300 km So, Time gap between the bikes that finished first and second = 6.5 – 6 = 30 minutes

Sol. (103-106): Let total number of boys in A = 4a So, total number of girls in B = 5a And, total number of girls in A = 5a × 100 = 6a Let total number of girls in C = b So, total number of boys in B = b+120 (given, number of girls is 120 less than the number of boys in School B) Total girls in A, B, C = 5a+6a+b = 11a+b Given, 11a+b = 650 Schools Total boys Total girls Total Students A 4a 6a 10a B b+120 5a 5a+b+120 C 420-b b 420

S103. Ans.(d) Sol. Given, 10a = 400 a = 40 So, total girls in A and B = 11×40 = 440 And, total number of girls in C = 650 – 440 = 210 Total number of boys in C = 420 – 210 = 210 And total number of boys in B = b+120 – 210 = 120

S104. Ans.(c) Sol. Total girls in A and B = 5a+6a = 11a ATQ, 11a – (420-b) = 11a+b – 420 Given, 11a+b = 650 So, required difference = 650 – 420 = 230

S105. Ans.(e) Sol. Required ratio = 4a: b Here two variables and not exact numerical values of variables So, we can’t determine the ratio


<!-- Page 36 -->

S106. Ans.(b) Sol. Total number of students in A and girls in B = 10a+5a = 15a Required ratio = 15a: 4a = 15: 4

S107. Ans.(d) Sol. Let the cost price of A and B be 4a and 5a respectively. Let the marked price of A and B be 3b and b respectively. Selling price of A = Rs 840 The selling price of A is Rs 840, which is Rs 840 more than the discount offered on it So, discount offered is 0 3b – 0 = 840 3b = 840 b = 280 The marked price of A and B be Rs 840 and Rs 280 respectively. Form I: The cost price of A = Rs 700 The cost price of B = 700 × 4 = Rs 875 The profit earned on B = 875 × 100 = Rs 175 I is sufficient. Form II: The selling price of A = Rs 840 Profit earned on B = 840 – 665 = 175 Rs II is sufficient.

Sol (108-110): In city A, Total people = 400 +700= 1100 People consumed alcoholic beverage = 400 Alcoholic beverages consumed by male = (400 + 200)/2 = 300 Alcoholic beverages consumed by female = 400 – 300 = 100 People consumed non - alcoholic beverages = 700 Female consumed non-alcoholic beverages = (700+40)/2 = 370 Male consumed non-alcoholic beverages = 700 – 370 = 330 In city B, Total people = 500 +200= 700 People consumed alcoholic beverage = 500 Alcoholic beverages consumed by male = 3+2 × 500 = 200 Alcoholic beverages consumed by female = 500 – 200 = 300 People consumed non - alcoholic beverages = 200 Female consumed non-alcoholic beverages = 100+150 × 200 = 120 Male consumed non-alcoholic beverages = 200 – 120 = 80 In city C, Total people = 600 +180= 780 People consumed alcoholic beverage = 600 Alcoholic beverages consumed by female = 7+5 × 600 = 250 Alcoholic beverages consumed by male = 600 – 250 = 350 People consumed non - alcoholic beverages = 180 male consumed non-alcoholic beverages = 100+50 × 180 = 60 female consumed non-alcoholic beverages = 180 – 60 = 120

S108. Ans.(b) Sol. Required answer = 350 -300 = 50

S109. Ans.(a) Sol. Required ratio = 300 +200: 120 = 500:120 = 25:6

S110. Ans.(b) Sol. Required answer = 700+180+200 = 1080 Required answer = 1080+1500 × 100 = 42%
