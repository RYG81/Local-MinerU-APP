# Quiz Extractor App

A local **CLI + Web UI** app for extracting quiz/question-paper PDFs into structured JSON with:

- preface / intro text
- questions
- options
- answer key
- directions (best-effort)
- related images
- page previews
- low-confidence review queue

It is designed for **bulk processing of thousands of PDFs**.

## What is included

- **Batch extractor** for a folder of PDFs
- **Canonical JSON output** per document
- **Raw page text + page images + extracted embedded images**
- **Review queue** for low-confidence questions
- **Web UI** to inspect/edit extracted questions
- **Optional Docling integration**

## Current engine behavior

This app works in two layers:

1. **Docling (optional, recommended)**
   - used for raw markdown / raw docling JSON when available
   - best for OCR + richer PDF understanding
2. **PyMuPDF (required fallback)**
   - used for page text extraction
   - used for page image rendering
   - used for embedded image extraction

So even without Docling installed, the app still runs.

## Folder structure

```text
app_data/
  input_pdfs/              # put your PDFs here
  raw/
    docling_json/
    markdown/
    page_images/
    picture_images/
    *_pages.json
  output/
    json/
    review/
  jobs/
```

## Install

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### Optional: install Docling

```bash
pip install docling
```

If Docling is installed, the app will try to use it automatically when engine=`auto`.

## Run batch extraction

Put PDFs in:

```text
app_data/input_pdfs/
```

Then run:

```bash
python batch_extract.py batch
```

Or specify a custom folder:

```bash
python batch_extract.py batch --input-dir /path/to/pdfs --engine auto
```

## Run web app

```bash
python run_web.py
```

Open:

```text
http://127.0.0.1:8000
```

## Output JSON

Each processed PDF creates:

```text
app_data/output/json/<document_id>.json
app_data/output/review/<document_id>_review.json
```

## Supported extraction patterns

### Question starts
- `Q1.`
- `Question 1.`

### Options
- `(a) (b) (c) (d)`
- `A. B. C. D.`

### Answers
- `Ans.(b)`
- `Answer: B`
- `Correct Answer: B`

## Notes

- This is a strong MVP for exam-style PDFs with repeated question patterns.
- For highly scanned / messy PDFs, install **Docling** and use the review queue.
- If you want an LLM repair layer next, it can be added on top of `needs_review=true` questions only.

## Main files

- `quiz_app/cli.py` — CLI
- `quiz_app/web/app.py` — web UI + API
- `quiz_app/extractor/converter.py` — raw PDF extraction
- `quiz_app/extractor/parser.py` — question/option/answer parser
- `quiz_app/extractor/linker.py` — image linking
- `quiz_app/schema.py` — canonical models

## Suggested next improvement

If you want, the next version can add:

- LLM repair for low-confidence questions
- exam-specific parsing profiles
- answer-key table parsing at end of PDF
- better grouped-directions / passage support
- OCR confidence and duplicate-logo filtering improvements
