from pathlib import Path
import unittest

from quiz_app.config import get_config
from quiz_app.extractor.pipeline import ExtractionPipeline


class PipelineTest(unittest.TestCase):
    def test_sample_exam_extraction(self):
        cfg = get_config()
        pdf_path = cfg.input_dir / "sample_exam.pdf"
        self.assertTrue(pdf_path.exists(), f"Missing sample PDF at {pdf_path}")
        pipeline = ExtractionPipeline(cfg)
        result = pipeline.process_pdf(pdf_path, engine="pymupdf")
        doc = result.document
        self.assertEqual(doc.document_id, "sample_exam")
        self.assertEqual(sum(len(section.questions) for section in doc.sections), 5)
        q3 = doc.sections[0].questions[2]
        self.assertEqual(q3.question_id, "q_3")
        self.assertEqual(q3.correct_answer.option_key, "a")
        self.assertEqual(len(q3.assets), 1)


if __name__ == "__main__":
    unittest.main()
