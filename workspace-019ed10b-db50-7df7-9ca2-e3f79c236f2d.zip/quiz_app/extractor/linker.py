from __future__ import annotations

from collections import Counter

from quiz_app.config import AppConfig
from quiz_app.schema import Asset, QuizDocument, RawExtraction


def link_assets(doc: QuizDocument, raw: RawExtraction, cfg: AppConfig) -> QuizDocument:
    hash_counts = Counter()
    for page in raw.pages:
        for img in page.extracted_images:
            hash_counts[img.hash] += 1

    images_by_page = {page.page_no: list(page.extracted_images) for page in raw.pages}

    for section in doc.sections:
        for question in section.questions:
            start_page = question.provenance.page_start or 1
            end_page = question.provenance.page_end or start_page
            candidate_pages = list(range(start_page, end_page + 1))
            placeholders = 0
            if question.raw_block:
                placeholders = question.raw_block.lower().count("image")
                if any(token in question.raw_block.lower() for token in ["diagram", "figure", "graph", "chart"]):
                    placeholders = max(placeholders, 1)

            candidate_assets = []
            for page_no in candidate_pages:
                for img in images_by_page.get(page_no, []):
                    if hash_counts[img.hash] >= 4:
                        continue
                    candidate_assets.append(img)

            to_attach = candidate_assets[: placeholders] if placeholders else []
            for idx, img in enumerate(to_attach, start=1):
                question.assets.append(
                    Asset(
                        asset_id=f"{question.question_id}_img_{idx}",
                        type="image",
                        path=img.path,
                        page=img.page,
                        role="question_diagram",
                        hash=img.hash,
                        width=img.width,
                        height=img.height,
                    )
                )

    assigned_hashes = {asset.hash for sec in doc.sections for q in sec.questions for asset in q.assets if asset.hash}
    for page in raw.pages:
        for idx, img in enumerate(page.extracted_images, start=1):
            if hash_counts[img.hash] >= 4 or img.hash in assigned_hashes:
                continue
            doc.unassigned_assets.append(
                Asset(
                    asset_id=f"page_{page.page_no}_img_{idx}",
                    type="image",
                    path=img.path,
                    page=img.page,
                    role="unassigned",
                    hash=img.hash,
                    width=img.width,
                    height=img.height,
                )
            )

    return doc
