from __future__ import annotations

import re
from pathlib import Path

from quiz_app.schema import (
    CorrectAnswer,
    DirectionBlock,
    Metadata,
    Option,
    PrefaceBlock,
    Provenance,
    Question,
    QuizDocument,
    RawExtraction,
    Section,
)
from quiz_app.utils import clean_question_text, normalize_text, slugify

QUESTION_RE = re.compile(r"(?<!\w)(Q(?:uestion)?\s*(\d{1,4})\s*[.)])", re.IGNORECASE)
ANSWER_PATTERNS = [
    re.compile(r"(?:Ans(?:wer)?\.?\s*[:\-]?\s*[\[(]?\s*([A-Da-d])\s*[\])]?)", re.IGNORECASE),
    re.compile(r"(?:Correct Answer\s*[:\-]\s*([A-Da-d]))", re.IGNORECASE),
]
OPTION_PATTERNS = [
    re.compile(r"\(([A-Da-d])\)\s*(.*?)(?=(?:\([A-Da-d]\)\s)|(?:Ans(?:wer)?\.?\s*[:\-]?)|$)", re.IGNORECASE | re.DOTALL),
    re.compile(r"(?:^|\s)([A-D])\.\s*(.*?)(?=(?:\s[A-D]\.\s)|(?:Ans(?:wer)?\.?\s*[:\-]?)|$)", re.IGNORECASE | re.DOTALL),
]
DIRECTION_PREFIX_RE = re.compile(r"^(Instruction|Instructions|Direction|Directions)\s*:\s*(.+)$", re.IGNORECASE | re.DOTALL)
YEAR_RE = re.compile(r"(20\d{2})")
SHIFT_RE = re.compile(r"\bS([1-4])\b", re.IGNORECASE)


def _page_for_index(page_starts: list[tuple[int, int]], index: int) -> int:
    current_page = 1
    for start_index, page_no in page_starts:
        if index >= start_index:
            current_page = page_no
        else:
            break
    return current_page


def _remove_page_markers(text: str) -> str:
    return re.sub(r"\[\[PAGE:(\d+)\]\]", "", text)


def _extract_answer(block: str) -> tuple[str | None, str]:
    for pattern in ANSWER_PATTERNS:
        match = None
        for candidate in pattern.finditer(block):
            match = candidate
        if match:
            answer = match.group(1).lower()
            cleaned = (block[: match.start()] + block[match.end() :]).strip()
            return answer, cleaned
    return None, block


def _extract_options(block: str) -> tuple[list[Option], str]:
    best_options: list[Option] = []
    best_stem = block
    for pattern in OPTION_PATTERNS:
        options = [
            Option(key=m.group(1).lower(), text=clean_question_text(_remove_page_markers(m.group(2))))
            for m in pattern.finditer(block)
        ]
        if len(options) > len(best_options):
            best_options = options
            if options:
                first = pattern.search(block)
                if first:
                    best_stem = block[: first.start()].strip()
    return best_options, best_stem


def _extract_direction(stem: str) -> tuple[str | None, str]:
    stem = clean_question_text(stem)
    match = DIRECTION_PREFIX_RE.match(stem)
    if not match:
        return None, stem

    rest = match.group(2).strip()
    # capture the first complete sentence as direction if possible
    sentence_match = re.match(r"(.{1,250}?[.?!])\s+(.*)", rest, re.DOTALL)
    if sentence_match:
        direction = clean_question_text(sentence_match.group(1))
        remaining = clean_question_text(sentence_match.group(2))
        if remaining:
            return direction, remaining
    return clean_question_text(rest), stem


def _score_question(question: Question) -> tuple[float, list[str]]:
    score = 1.0
    reasons: list[str] = []
    if not question.stem or len(question.stem) < 12:
        score -= 0.15
        reasons.append("stem_too_short")
    if not question.options:
        score -= 0.30
        reasons.append("no_options")
    if 0 < len(question.options) < 4:
        score -= 0.15
        reasons.append("fewer_than_4_options")
    option_keys = [opt.key for opt in question.options]
    if len(option_keys) != len(set(option_keys)):
        score -= 0.20
        reasons.append("duplicate_option_keys")
    if not question.correct_answer or not question.correct_answer.option_key:
        score -= 0.35
        reasons.append("missing_answer")
    elif question.correct_answer.option_key not in option_keys:
        score -= 0.20
        reasons.append("answer_not_in_options")
    if question.raw_block and question.raw_block.lower().count("image") > 0 and not question.assets:
        score -= 0.10
        reasons.append("image_placeholder_without_asset")
    return max(score, 0.0), reasons


def _derive_metadata(raw: RawExtraction) -> Metadata:
    source = raw.source_pdf
    title = raw.title or Path(source).stem
    year_match = YEAR_RE.search(source) or YEAR_RE.search(title)
    shift_match = SHIFT_RE.search(source) or SHIFT_RE.search(title)
    exam = None
    for token in ["ssc selection post", "ssc gd", "ssc cpo", "ssc mts"]:
        if token in source.lower() or token in title.lower():
            exam = token.upper()
            break
    return Metadata(
        title=title,
        exam=exam,
        language="en",
        year=int(year_match.group(1)) if year_match else None,
        shift=f"S{shift_match.group(1)}" if shift_match else None,
        pages=len(raw.pages),
    )


def parse_quiz(raw: RawExtraction) -> tuple[QuizDocument, list[dict[str, str | int | float | None]]]:
    page_starts: list[tuple[int, int]] = []
    combined_parts: list[str] = []
    char_count = 0
    for page in raw.pages:
        marker = f"\n[[PAGE:{page.page_no}]]\n"
        page_starts.append((char_count, page.page_no))
        normalized_page_text = normalize_text(page.text)
        combined_parts.append(marker)
        combined_parts.append(normalized_page_text)
        char_count += len(marker) + len(normalized_page_text)
    combined_text = "".join(combined_parts)

    matches = list(QUESTION_RE.finditer(combined_text))
    preface_text = _remove_page_markers(combined_text[: matches[0].start()] if matches else combined_text).strip()

    questions: list[Question] = []
    directions: list[DirectionBlock] = []
    review_rows: list[dict[str, str | int | float | None]] = []

    for idx, match in enumerate(matches):
        question_number = int(match.group(2))
        start = match.start()
        end = matches[idx + 1].start() if idx + 1 < len(matches) else len(combined_text)
        raw_block = combined_text[start:end].strip()
        block_without_q = raw_block[len(match.group(1)) :].strip()
        answer_key, no_answer_block = _extract_answer(block_without_q)
        options, stem_block = _extract_options(no_answer_block)
        direction_text, stem = _extract_direction(stem_block)

        start_page = _page_for_index(page_starts, start)
        end_page = _page_for_index(page_starts, max(start, end - 1))

        direction_refs: list[str] = []
        if direction_text:
            direction_id = f"dir_{question_number}"
            directions.append(
                DirectionBlock(
                    direction_id=direction_id,
                    text=direction_text,
                    question_range=[question_number, question_number],
                    page_start=start_page,
                    page_end=end_page,
                )
            )
            direction_refs.append(direction_id)

        correct_answer = None
        if answer_key:
            answer_text = next((opt.text for opt in options if opt.key == answer_key), None)
            correct_answer = CorrectAnswer(option_key=answer_key, answer_text=answer_text)

        question = Question(
            question_id=f"q_{question_number}",
            question_number=question_number,
            stem=clean_question_text(_remove_page_markers(stem)),
            options=options,
            correct_answer=correct_answer,
            direction_refs=direction_refs,
            provenance=Provenance(page_start=start_page, page_end=end_page, source_spans=[]),
            raw_block=clean_question_text(_remove_page_markers(raw_block)),
        )
        confidence, reasons = _score_question(question)
        question.parse_confidence = confidence
        question.needs_review = confidence < 0.8
        questions.append(question)

        if question.needs_review:
            reason = ", ".join(reasons) or "low_confidence"
            review_rows.append(
                {
                    "question_id": question.question_id,
                    "question_number": question.question_number,
                    "reason": reason,
                    "parse_confidence": confidence,
                    "page_start": start_page,
                    "page_end": end_page,
                }
            )

    section = Section(section_id="section_1", title=None, directions=directions, questions=questions)
    preface_blocks = [PrefaceBlock(text=clean_question_text(preface_text), page_start=1, page_end=1)] if preface_text else []
    document_confidence = round(sum(q.parse_confidence for q in questions) / max(len(questions), 1), 3)

    doc = QuizDocument(
        document_id=slugify(Path(raw.source_pdf).stem),
        source_pdf=raw.source_pdf,
        metadata=_derive_metadata(raw),
        preface=preface_blocks,
        sections=[section],
        unassigned_assets=[],
        document_parse_confidence=document_confidence,
        parser_version="v1",
    )
    return doc, review_rows
