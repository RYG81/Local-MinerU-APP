from __future__ import annotations

import io
import logging
from pathlib import Path
from typing import Literal

import fitz  # type: ignore
from PIL import Image

from quiz_app.config import AppConfig
from quiz_app.schema import RawExtraction, RawImage, RawPage
from quiz_app.utils import save_json, sha256_bytes, slugify

LOGGER = logging.getLogger(__name__)
EngineName = Literal["auto", "docling", "pymupdf"]


def _try_docling_export(pdf_path: Path, cfg: AppConfig, document_id: str) -> tuple[str | None, str | None, list[str]]:
    notes: list[str] = []
    try:
        from docling.document_converter import DocumentConverter, PdfFormatOption
        from docling.datamodel.base_models import InputFormat
        from docling.datamodel.pipeline_options import PdfPipelineOptions
    except Exception as exc:  # pragma: no cover - optional dependency path
        notes.append(f"Docling unavailable: {exc}")
        return None, None, notes

    try:  # pragma: no cover - optional dependency path
        pipeline_options = PdfPipelineOptions()
        pipeline_options.do_ocr = True
        pipeline_options.do_table_structure = True
        pipeline_options.generate_picture_images = True
        pipeline_options.generate_page_images = True
        pipeline_options.images_scale = 2.0

        converter = DocumentConverter(
            format_options={InputFormat.PDF: PdfFormatOption(pipeline_options=pipeline_options)}
        )
        result = converter.convert(str(pdf_path))
        doc = result.document

        md_path = cfg.markdown_dir / f"{document_id}.md"
        json_path = cfg.docling_json_dir / f"{document_id}.json"
        md_path.write_text(doc.export_to_markdown(), encoding="utf-8")
        save_json(json_path, doc.export_to_dict())
        notes.append("Docling export succeeded.")
        return str(json_path), str(md_path), notes
    except Exception as exc:  # pragma: no cover - optional dependency path
        LOGGER.exception("Docling conversion failed for %s", pdf_path)
        notes.append(f"Docling conversion failed: {exc}")
        return None, None, notes


def _save_page_image(page: fitz.Page, out_path: Path) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    pix = page.get_pixmap(matrix=fitz.Matrix(1.5, 1.5), alpha=False)
    pix.save(out_path)


def _save_image_bytes(image_bytes: bytes, out_path: Path) -> tuple[int | None, int | None]:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(image_bytes)
    try:
        with Image.open(io.BytesIO(image_bytes)) as img:
            return img.width, img.height
    except Exception:
        return None, None


def extract_raw(pdf_path: Path, cfg: AppConfig, engine: EngineName = "auto") -> RawExtraction:
    document_id = slugify(pdf_path.stem)
    page_dir = cfg.page_images_dir / document_id
    image_dir = cfg.extracted_images_dir / document_id
    page_dir.mkdir(parents=True, exist_ok=True)
    image_dir.mkdir(parents=True, exist_ok=True)

    selected_engine = "pymupdf"
    notes: list[str] = []
    docling_json_path: str | None = None
    markdown_path: str | None = None

    if engine in {"auto", "docling"}:
        docling_json_path, markdown_path, docling_notes = _try_docling_export(pdf_path, cfg, document_id)
        notes.extend(docling_notes)
        if docling_json_path or markdown_path:
            selected_engine = "docling+pymupdf"
        elif engine == "docling":
            notes.append("Falling back to PyMuPDF text extraction because Docling was unavailable or failed.")

    pages: list[RawPage] = []
    seen_hashes: dict[str, int] = {}
    pdf = fitz.open(pdf_path)
    try:
        for page_index, page in enumerate(pdf, start=1):
            page_image_path = page_dir / f"page_{page_index:03d}.png"
            _save_page_image(page, page_image_path)

            text = page.get_text("text") or ""
            extracted_images: list[RawImage] = []
            for image_idx, image_info in enumerate(page.get_images(full=True), start=1):
                xref = image_info[0]
                try:
                    base = pdf.extract_image(xref)
                except Exception:
                    continue
                image_bytes = base.get("image")
                ext = base.get("ext", "png")
                if not image_bytes:
                    continue
                digest = sha256_bytes(image_bytes)
                seen_hashes[digest] = seen_hashes.get(digest, 0) + 1
                image_path = image_dir / f"page_{page_index:03d}_img_{image_idx:03d}.{ext}"
                width, height = _save_image_bytes(image_bytes, image_path)
                extracted_images.append(
                    RawImage(
                        page=page_index,
                        path=str(image_path.relative_to(cfg.project_root)),
                        hash=digest,
                        width=width,
                        height=height,
                    )
                )

            pages.append(
                RawPage(
                    page_no=page_index,
                    text=text,
                    page_image_path=str(page_image_path.relative_to(cfg.project_root)),
                    extracted_images=extracted_images,
                )
            )
    finally:
        pdf.close()

    raw = RawExtraction(
        engine=selected_engine,
        source_pdf=pdf_path.name,
        title=pdf_path.stem,
        pages=pages,
        markdown_path=markdown_path and str(Path(markdown_path).relative_to(cfg.project_root)),
        docling_json_path=docling_json_path and str(Path(docling_json_path).relative_to(cfg.project_root)),
        notes=notes,
    )
    save_json(cfg.raw_dir / f"{document_id}_pages.json", raw.model_dump())
    return raw
