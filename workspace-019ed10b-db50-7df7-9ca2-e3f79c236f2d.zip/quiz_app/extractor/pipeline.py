from __future__ import annotations

import logging
from pathlib import Path

from quiz_app.config import AppConfig
from quiz_app.extractor.converter import extract_raw
from quiz_app.extractor.linker import link_assets
from quiz_app.extractor.parser import parse_quiz
from quiz_app.extractor.review import build_review_items
from quiz_app.schema import QuizDocument, ReviewItem
from quiz_app.utils import save_json, slugify

LOGGER = logging.getLogger(__name__)


class ExtractionResult:
    def __init__(self, document: QuizDocument, review_items: list[ReviewItem], json_path: Path, review_path: Path):
        self.document = document
        self.review_items = review_items
        self.json_path = json_path
        self.review_path = review_path


class ExtractionPipeline:
    def __init__(self, cfg: AppConfig):
        self.cfg = cfg

    def process_pdf(self, pdf_path: Path, engine: str = "auto") -> ExtractionResult:
        raw = extract_raw(pdf_path, self.cfg, engine=engine)  # type: ignore[arg-type]
        document, review_rows = parse_quiz(raw)
        document = link_assets(document, raw, self.cfg)

        # rescore if images were attached after parsing
        for section in document.sections:
            for question in section.questions:
                if question.raw_block and question.raw_block.lower().count("image") > 0 and question.assets:
                    question.parse_confidence = min(1.0, question.parse_confidence + 0.1)
                    question.needs_review = question.parse_confidence < 0.8
        all_questions = [q for section in document.sections for q in section.questions]
        document.document_parse_confidence = round(
            sum(q.parse_confidence for q in all_questions) / max(len(all_questions), 1), 3)

        review_items = build_review_items(document, review_rows)
        json_path = self.cfg.json_dir / f"{document.document_id}.json"
        review_path = self.cfg.review_dir / f"{document.document_id}_review.json"
        save_json(json_path, document.model_dump())
        save_json(review_path, [item.model_dump() for item in review_items])
        return ExtractionResult(document, review_items, json_path, review_path)

    def process_directory(self, input_dir: Path | None = None, engine: str = "auto") -> list[ExtractionResult]:
        source_dir = input_dir or self.cfg.input_dir
        pdf_files = sorted(source_dir.glob("*.pdf"))
        results: list[ExtractionResult] = []
        for pdf_path in pdf_files:
            LOGGER.info("Processing %s", pdf_path)
            results.append(self.process_pdf(pdf_path, engine=engine))
        return results

    def update_question(self, document_id: str, question_id: str, payload: dict) -> Path:
        json_path = self.cfg.json_dir / f"{slugify(document_id)}.json"
        if not json_path.exists():
            raise FileNotFoundError(f"Document JSON not found: {json_path}")
        document = QuizDocument.model_validate_json(json_path.read_text(encoding="utf-8"))
        for section in document.sections:
            for question in section.questions:
                if question.question_id == question_id:
                    for key in ["stem", "solution", "needs_review"]:
                        if key in payload:
                            setattr(question, key, payload[key])
                    if "correct_answer" in payload and isinstance(payload["correct_answer"], dict):
                        for field, value in payload["correct_answer"].items():
                            if question.correct_answer is None:
                                from quiz_app.schema import CorrectAnswer

                                question.correct_answer = CorrectAnswer()
                            setattr(question.correct_answer, field, value)
                    if "options" in payload and isinstance(payload["options"], list):
                        from quiz_app.schema import Option

                        question.options = [Option.model_validate(item) for item in payload["options"]]
                    save_json(json_path, document.model_dump())
                    return json_path
        raise ValueError(f"Question not found: {question_id}")
