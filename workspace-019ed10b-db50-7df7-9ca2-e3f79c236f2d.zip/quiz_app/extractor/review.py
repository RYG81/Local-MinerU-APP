from __future__ import annotations

from quiz_app.schema import QuizDocument, ReviewItem


def build_review_items(doc: QuizDocument, rows: list[dict]) -> list[ReviewItem]:
    items: list[ReviewItem] = []
    for row in rows:
        items.append(
            ReviewItem(
                document_id=doc.document_id,
                question_id=str(row.get("question_id")),
                question_number=row.get("question_number"),
                reason=str(row.get("reason", "low_confidence")),
                parse_confidence=float(row.get("parse_confidence", 0.0)),
                source_pdf=doc.source_pdf,
                page_start=row.get("page_start"),
                page_end=row.get("page_end"),
            )
        )
    return items
