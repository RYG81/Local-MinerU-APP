from __future__ import annotations

import argparse
import json
import logging
from pathlib import Path

from quiz_app.config import get_config
from quiz_app.extractor.pipeline import ExtractionPipeline

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")


def cmd_batch(args: argparse.Namespace) -> int:
    cfg = get_config()
    pipeline = ExtractionPipeline(cfg)
    input_dir = Path(args.input_dir) if args.input_dir else cfg.input_dir
    results = pipeline.process_directory(input_dir=input_dir, engine=args.engine)
    summary = [
        {
            "document_id": result.document.document_id,
            "source_pdf": result.document.source_pdf,
            "questions": sum(len(section.questions) for section in result.document.sections),
            "confidence": result.document.document_parse_confidence,
            "json_path": str(result.json_path.relative_to(cfg.project_root)),
            "review_items": len(result.review_items),
        }
        for result in results
    ]
    print(json.dumps(summary, indent=2))
    return 0


def cmd_serve(args: argparse.Namespace) -> int:
    import uvicorn

    uvicorn.run("quiz_app.web.app:app", host=args.host, port=args.port, reload=False)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Quiz extraction app")
    sub = parser.add_subparsers(dest="command", required=True)

    batch = sub.add_parser("batch", help="Process a folder of PDFs")
    batch.add_argument("--input-dir", default=None, help="Folder containing PDF files")
    batch.add_argument("--engine", default="auto", choices=["auto", "docling", "pymupdf"])
    batch.set_defaults(func=cmd_batch)

    serve = sub.add_parser("serve", help="Run the web app")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=8000)
    serve.set_defaults(func=cmd_serve)

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
