from __future__ import annotations

from typing import Any, Literal
from pydantic import BaseModel, Field


class Metadata(BaseModel):
    title: str | None = None
    exam: str | None = None
    language: str | None = None
    year: int | None = None
    shift: str | None = None
    pages: int | None = None
    source_url: str | None = None


class PrefaceBlock(BaseModel):
    text: str
    page_start: int | None = None
    page_end: int | None = None


class DirectionBlock(BaseModel):
    direction_id: str
    text: str
    question_range: list[int] | None = None
    page_start: int | None = None
    page_end: int | None = None


class Asset(BaseModel):
    asset_id: str
    type: Literal["image", "table", "page_crop", "diagram"] = "image"
    path: str
    page: int | None = None
    bbox: list[float] | None = None
    role: str | None = None
    hash: str | None = None
    width: int | None = None
    height: int | None = None


class Option(BaseModel):
    key: str
    text: str


class CorrectAnswer(BaseModel):
    option_key: str | None = None
    answer_text: str | None = None


class Provenance(BaseModel):
    page_start: int | None = None
    page_end: int | None = None
    source_spans: list[dict[str, Any]] = Field(default_factory=list)


class Stimulus(BaseModel):
    type: str | None = None
    text: str | None = None
    assets: list[Asset] = Field(default_factory=list)


class Question(BaseModel):
    question_id: str
    question_number: int | str
    type: str = "mcq_single"
    stem: str
    options: list[Option] = Field(default_factory=list)
    correct_answer: CorrectAnswer | None = None
    solution: str | None = None
    direction_refs: list[str] = Field(default_factory=list)
    assets: list[Asset] = Field(default_factory=list)
    stimulus: Stimulus | None = None
    provenance: Provenance = Field(default_factory=Provenance)
    parse_confidence: float = 0.0
    needs_review: bool = False
    raw_block: str | None = None


class Section(BaseModel):
    section_id: str
    title: str | None = None
    directions: list[DirectionBlock] = Field(default_factory=list)
    questions: list[Question] = Field(default_factory=list)


class QuizDocument(BaseModel):
    document_id: str
    source_pdf: str
    metadata: Metadata
    preface: list[PrefaceBlock] = Field(default_factory=list)
    sections: list[Section] = Field(default_factory=list)
    unassigned_assets: list[Asset] = Field(default_factory=list)
    document_parse_confidence: float = 0.0
    parser_version: str = "v1"


class ReviewItem(BaseModel):
    document_id: str
    question_id: str
    question_number: int | str
    reason: str
    parse_confidence: float
    source_pdf: str
    page_start: int | None = None
    page_end: int | None = None


class RawImage(BaseModel):
    page: int
    path: str
    hash: str
    width: int | None = None
    height: int | None = None


class RawPage(BaseModel):
    page_no: int
    text: str
    page_image_path: str | None = None
    extracted_images: list[RawImage] = Field(default_factory=list)


class RawExtraction(BaseModel):
    engine: str
    title: str | None = None
    source_pdf: str
    pages: list[RawPage] = Field(default_factory=list)
    markdown_path: str | None = None
    docling_json_path: str | None = None
    notes: list[str] = Field(default_factory=list)


class JobStatus(BaseModel):
    job_id: str
    status: Literal["queued", "running", "completed", "failed"]
    message: str = ""
    processed: int = 0
    total: int = 0
    started_at: str | None = None
    ended_at: str | None = None
    outputs: list[str] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)
