from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import os


@dataclass(frozen=True)
class AppConfig:
    project_root: Path
    data_root: Path
    input_dir: Path
    raw_dir: Path
    output_dir: Path
    json_dir: Path
    review_dir: Path
    jobs_dir: Path
    page_images_dir: Path
    extracted_images_dir: Path
    docling_json_dir: Path
    markdown_dir: Path


def get_config() -> AppConfig:
    project_root = Path(__file__).resolve().parent.parent
    data_root = Path(os.getenv("QUIZ_APP_DATA_ROOT", project_root / "app_data"))
    input_dir = Path(os.getenv("QUIZ_APP_INPUT_DIR", data_root / "input_pdfs"))
    raw_dir = data_root / "raw"
    output_dir = data_root / "output"
    cfg = AppConfig(
        project_root=project_root,
        data_root=data_root,
        input_dir=input_dir,
        raw_dir=raw_dir,
        output_dir=output_dir,
        json_dir=output_dir / "json",
        review_dir=output_dir / "review",
        jobs_dir=data_root / "jobs",
        page_images_dir=raw_dir / "page_images",
        extracted_images_dir=raw_dir / "picture_images",
        docling_json_dir=raw_dir / "docling_json",
        markdown_dir=raw_dir / "markdown",
    )
    for path in [
        cfg.data_root,
        cfg.input_dir,
        cfg.raw_dir,
        cfg.output_dir,
        cfg.json_dir,
        cfg.review_dir,
        cfg.jobs_dir,
        cfg.page_images_dir,
        cfg.extracted_images_dir,
        cfg.docling_json_dir,
        cfg.markdown_dir,
    ]:
        path.mkdir(parents=True, exist_ok=True)
    return cfg
