from __future__ import annotations

import json
import threading
import traceback
import uuid
from pathlib import Path
from typing import Any

from fastapi import Body, FastAPI, HTTPException
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from pydantic import BaseModel

from quiz_app.config import get_config
from quiz_app.extractor.pipeline import ExtractionPipeline
from quiz_app.schema import JobStatus, QuizDocument
from quiz_app.utils import load_json, save_json, slugify, utc_now_iso

cfg = get_config()
app = FastAPI(title="Quiz Extractor App")
pipeline = ExtractionPipeline(cfg)


class ExtractRequest(BaseModel):
    input_dir: str | None = None
    engine: str = "auto"


class QuestionUpdateRequest(BaseModel):
    stem: str | None = None
    solution: str | None = None
    needs_review: bool | None = None
    correct_answer: dict[str, Any] | None = None
    options: list[dict[str, Any]] | None = None


class JobManager:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self.jobs: dict[str, JobStatus] = {}
        self._load_existing()

    def _job_path(self, job_id: str) -> Path:
        return cfg.jobs_dir / f"{job_id}.json"

    def _load_existing(self) -> None:
        for path in cfg.jobs_dir.glob("*.json"):
            try:
                job = JobStatus.model_validate(load_json(path))
                self.jobs[job.job_id] = job
            except Exception:
                continue

    def _save(self, job: JobStatus) -> None:
        save_json(self._job_path(job.job_id), job.model_dump())

    def list_jobs(self) -> list[JobStatus]:
        with self._lock:
            return sorted(self.jobs.values(), key=lambda job: job.started_at or "", reverse=True)

    def get_job(self, job_id: str) -> JobStatus:
        with self._lock:
            job = self.jobs.get(job_id)
        if not job:
            raise KeyError(job_id)
        return job

    def submit_extraction(self, input_dir: str | None, engine: str) -> JobStatus:
        source_dir = Path(input_dir) if input_dir else cfg.input_dir
        pdf_files = sorted(source_dir.glob("*.pdf"))
        job_id = uuid.uuid4().hex[:12]
        job = JobStatus(
            job_id=job_id,
            status="queued",
            message=f"Queued {len(pdf_files)} PDF(s)",
            processed=0,
            total=len(pdf_files),
            started_at=utc_now_iso(),
            outputs=[],
            errors=[],
        )
        with self._lock:
            self.jobs[job_id] = job
            self._save(job)
        thread = threading.Thread(target=self._run_extraction, args=(job_id, source_dir, engine), daemon=True)
        thread.start()
        return job

    def _run_extraction(self, job_id: str, source_dir: Path, engine: str) -> None:
        try:
            with self._lock:
                job = self.jobs[job_id]
                job.status = "running"
                job.message = f"Processing PDFs from {source_dir}"
                self._save(job)

            pdf_files = sorted(source_dir.glob("*.pdf"))
            for index, pdf_path in enumerate(pdf_files, start=1):
                result = pipeline.process_pdf(pdf_path, engine=engine)
                with self._lock:
                    job = self.jobs[job_id]
                    job.processed = index
                    job.message = f"Processed {pdf_path.name}"
                    job.outputs.append(str(result.json_path.relative_to(cfg.project_root)))
                    self._save(job)

            with self._lock:
                job = self.jobs[job_id]
                job.status = "completed"
                job.ended_at = utc_now_iso()
                job.message = f"Completed {len(pdf_files)} PDF(s)"
                self._save(job)
        except Exception as exc:
            with self._lock:
                job = self.jobs[job_id]
                job.status = "failed"
                job.ended_at = utc_now_iso()
                job.message = str(exc)
                job.errors.append(traceback.format_exc())
                self._save(job)


job_manager = JobManager()


def list_document_paths() -> list[Path]:
    return sorted(cfg.json_dir.glob("*.json"))


def load_document(document_id: str) -> QuizDocument:
    path = cfg.json_dir / f"{slugify(document_id)}.json"
    if not path.exists():
        raise FileNotFoundError(document_id)
    return QuizDocument.model_validate_json(path.read_text(encoding="utf-8"))


@app.get("/", response_class=HTMLResponse)
def index() -> str:
    return HTMLResponse(PAGE_HTML)


@app.get("/api/config")
def api_config() -> dict[str, str]:
    return {
        "project_root": str(cfg.project_root),
        "input_dir": str(cfg.input_dir),
        "json_dir": str(cfg.json_dir),
        "review_dir": str(cfg.review_dir),
        "raw_dir": str(cfg.raw_dir),
    }


@app.get("/api/jobs")
def api_jobs() -> list[dict[str, Any]]:
    return [job.model_dump() for job in job_manager.list_jobs()]


@app.get("/api/jobs/{job_id}")
def api_job(job_id: str) -> dict[str, Any]:
    try:
        return job_manager.get_job(job_id).model_dump()
    except KeyError:
        raise HTTPException(status_code=404, detail="Job not found")


@app.post("/api/extract")
def api_extract(request: ExtractRequest) -> dict[str, Any]:
    job = job_manager.submit_extraction(request.input_dir, request.engine)
    return job.model_dump()


@app.get("/api/documents")
def api_documents() -> list[dict[str, Any]]:
    docs = []
    for path in list_document_paths():
        doc = QuizDocument.model_validate_json(path.read_text(encoding="utf-8"))
        docs.append(
            {
                "document_id": doc.document_id,
                "source_pdf": doc.source_pdf,
                "title": doc.metadata.title,
                "questions": sum(len(section.questions) for section in doc.sections),
                "confidence": doc.document_parse_confidence,
                "needs_review": sum(1 for section in doc.sections for q in section.questions if q.needs_review),
            }
        )
    return docs


@app.get("/api/documents/{document_id}")
def api_document(document_id: str) -> dict[str, Any]:
    try:
        return load_document(document_id).model_dump()
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Document not found")


@app.get("/api/review")
def api_review() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for path in list_document_paths():
        doc = QuizDocument.model_validate_json(path.read_text(encoding="utf-8"))
        for section in doc.sections:
            for question in section.questions:
                if question.needs_review:
                    rows.append(
                        {
                            "document_id": doc.document_id,
                            "source_pdf": doc.source_pdf,
                            "question_id": question.question_id,
                            "question_number": question.question_number,
                            "stem": question.stem,
                            "confidence": question.parse_confidence,
                            "page_start": question.provenance.page_start,
                            "page_end": question.provenance.page_end,
                        }
                    )
    return rows


@app.post("/api/documents/{document_id}/questions/{question_id}")
def api_update_question(document_id: str, question_id: str, payload: QuestionUpdateRequest = Body(...)) -> dict[str, Any]:
    try:
        path = pipeline.update_question(document_id, question_id, payload.model_dump(exclude_none=True))
        return {"ok": True, "path": str(path.relative_to(cfg.project_root))}
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Document not found")
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


@app.get("/files/{file_path:path}")
def api_file(file_path: str):
    requested = (cfg.project_root / file_path).resolve()
    if not requested.exists() or cfg.project_root.resolve() not in requested.parents and requested != cfg.project_root.resolve():
        raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(requested)


PAGE_HTML = r'''<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Quiz Extractor App</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 0; background: #f5f7fb; color: #1f2937; }
    header { background: #111827; color: white; padding: 16px 20px; }
    header h1 { margin: 0; font-size: 22px; }
    .layout { display: grid; grid-template-columns: 320px 1fr; min-height: calc(100vh - 60px); }
    .sidebar { background: white; border-right: 1px solid #e5e7eb; padding: 16px; overflow: auto; }
    .main { padding: 16px; overflow: auto; }
    .card { background: white; border: 1px solid #e5e7eb; border-radius: 12px; padding: 16px; margin-bottom: 16px; box-shadow: 0 1px 2px rgba(0,0,0,0.03); }
    .btn { background: #2563eb; color: white; border: none; border-radius: 8px; padding: 10px 14px; cursor: pointer; }
    .btn.secondary { background: #6b7280; }
    .btn.small { padding: 6px 10px; font-size: 12px; }
    input, select, textarea { width: 100%; box-sizing: border-box; border: 1px solid #d1d5db; border-radius: 8px; padding: 10px; margin-top: 6px; }
    textarea { min-height: 120px; }
    .muted { color: #6b7280; font-size: 13px; }
    .row { display: flex; gap: 10px; align-items: center; }
    .row > * { flex: 1; }
    .pill { display: inline-block; padding: 4px 8px; border-radius: 999px; background: #eef2ff; color: #3730a3; font-size: 12px; margin-right: 6px; }
    .doc-item, .review-item, .job-item { padding: 10px; border: 1px solid #e5e7eb; border-radius: 10px; margin-bottom: 10px; cursor: pointer; }
    .doc-item:hover, .review-item:hover { border-color: #93c5fd; background: #f8fbff; }
    .question { border-top: 1px solid #e5e7eb; padding-top: 14px; margin-top: 14px; }
    .option { background: #f9fafb; border-radius: 8px; padding: 8px; margin: 6px 0; }
    .assets img, .page-preview img { max-width: 100%; border: 1px solid #ddd; border-radius: 8px; margin-top: 8px; }
    .split { display: grid; grid-template-columns: 1.2fr 0.8fr; gap: 16px; }
    .hidden { display: none; }
    .status-running { color: #2563eb; }
    .status-completed { color: #059669; }
    .status-failed { color: #dc2626; }
    pre { white-space: pre-wrap; word-wrap: break-word; background: #f9fafb; padding: 10px; border-radius: 8px; }
  </style>
</head>
<body>
  <header><h1>Quiz Extractor App</h1></header>
  <div class="layout">
    <div class="sidebar">
      <div class="card">
        <h3 style="margin-top:0">Run Extraction</h3>
        <label>Input directory</label>
        <input id="inputDir" placeholder="/path/to/pdfs" />
        <label>Engine</label>
        <select id="engine">
          <option value="auto">auto</option>
          <option value="docling">docling</option>
          <option value="pymupdf">pymupdf</option>
        </select>
        <div class="row" style="margin-top:12px">
          <button class="btn" onclick="startExtraction()">Start job</button>
          <button class="btn secondary" onclick="refreshAll()">Refresh</button>
        </div>
        <p class="muted" id="configInfo"></p>
      </div>

      <div class="card">
        <h3 style="margin-top:0">Jobs</h3>
        <div id="jobs"></div>
      </div>

      <div class="card">
        <h3 style="margin-top:0">Documents</h3>
        <div id="documents"></div>
      </div>

      <div class="card">
        <h3 style="margin-top:0">Review Queue</h3>
        <div id="review"></div>
      </div>
    </div>
    <div class="main">
      <div class="card" id="welcomeCard">
        <h2 style="margin-top:0">What this app does</h2>
        <ul>
          <li>Processes a folder of local PDFs</li>
          <li>Extracts quiz/questions/options/answers into canonical JSON</li>
          <li>Saves raw page text, page images, extracted images, final JSON, and review queue</li>
          <li>Lets you inspect and edit low-confidence questions</li>
        </ul>
      </div>
      <div id="documentView"></div>
    </div>
  </div>

<script>
let currentDocument = null;

async function api(path, options={}) {
  const response = await fetch(path, {
    headers: { 'Content-Type': 'application/json' },
    ...options
  });
  if (!response.ok) {
    const text = await response.text();
    throw new Error(text || response.statusText);
  }
  return response.json();
}

async function loadConfig() {
  const cfg = await api('/api/config');
  document.getElementById('inputDir').value = cfg.input_dir;
  document.getElementById('configInfo').textContent = `Input: ${cfg.input_dir}`;
}

async function loadJobs() {
  const jobs = await api('/api/jobs');
  const el = document.getElementById('jobs');
  el.innerHTML = jobs.length ? '' : '<div class="muted">No jobs yet</div>';
  jobs.forEach(job => {
    const div = document.createElement('div');
    div.className = 'job-item';
    div.innerHTML = `<div><strong>${job.job_id}</strong> <span class="status-${job.status}">${job.status}</span></div>
      <div class="muted">${job.message}</div>
      <div class="muted">${job.processed}/${job.total}</div>`;
    el.appendChild(div);
  });
}

async function loadDocuments() {
  const docs = await api('/api/documents');
  const el = document.getElementById('documents');
  el.innerHTML = docs.length ? '' : '<div class="muted">No extracted documents yet</div>';
  docs.forEach(doc => {
    const div = document.createElement('div');
    div.className = 'doc-item';
    div.innerHTML = `<div><strong>${doc.source_pdf}</strong></div>
      <div class="muted">Questions: ${doc.questions} | Confidence: ${doc.confidence} | Review: ${doc.needs_review}</div>`;
    div.onclick = () => showDocument(doc.document_id);
    el.appendChild(div);
  });
}

async function loadReview() {
  const rows = await api('/api/review');
  const el = document.getElementById('review');
  el.innerHTML = rows.length ? '' : '<div class="muted">No review items</div>';
  rows.slice(0, 50).forEach(row => {
    const div = document.createElement('div');
    div.className = 'review-item';
    div.innerHTML = `<div><strong>${row.document_id} / ${row.question_id}</strong></div>
      <div class="muted">p.${row.page_start || '?'}-${row.page_end || '?'} | conf ${row.confidence}</div>
      <div>${escapeHtml((row.stem || '').slice(0, 120))}</div>`;
    div.onclick = () => showDocument(row.document_id, row.question_id);
    el.appendChild(div);
  });
}

function renderQuestionEditor(doc, question) {
  const optionsJson = JSON.stringify(question.options || [], null, 2);
  const correctAnswer = JSON.stringify(question.correct_answer || {}, null, 2);
  const assetHtml = (question.assets || []).map(asset => `
    <div class="option">
      <div><strong>${asset.asset_id}</strong> (${asset.role || asset.type})</div>
      <div class="muted">${asset.path}</div>
      <img src="/files/${asset.path}" alt="asset" />
    </div>`).join('');

  const pages = [];
  for (let p = question.provenance.page_start || 1; p <= (question.provenance.page_end || question.provenance.page_start || 1); p++) {
    const imgPath = `app_data/raw/page_images/${doc.document_id}/page_${String(p).padStart(3,'0')}.png`;
    pages.push(`<div class="page-preview"><div class="muted">Page ${p}</div><img src="/files/${imgPath}" alt="page ${p}" /></div>`);
  }

  return `
    <div class="question" id="${question.question_id}">
      <div class="split">
        <div>
          <div class="pill">${question.question_id}</div>
          <div class="pill">confidence ${question.parse_confidence}</div>
          <div class="pill">review ${question.needs_review}</div>
          <h3>${question.question_id} — Q${question.question_number}</h3>
          <label>Stem</label>
          <textarea id="stem_${question.question_id}">${escapeHtml(question.stem || '')}</textarea>
          <label>Options (JSON array)</label>
          <textarea id="options_${question.question_id}">${escapeHtml(optionsJson)}</textarea>
          <label>Correct answer (JSON object)</label>
          <textarea id="answer_${question.question_id}">${escapeHtml(correctAnswer)}</textarea>
          <label>Solution</label>
          <textarea id="solution_${question.question_id}">${escapeHtml(question.solution || '')}</textarea>
          <div class="row" style="margin-top:10px">
            <button class="btn small" onclick="saveQuestion('${doc.document_id}','${question.question_id}')">Save</button>
            <button class="btn secondary small" onclick="markReviewed('${doc.document_id}','${question.question_id}')">Mark reviewed</button>
          </div>
          <details style="margin-top:10px"><summary>Raw block</summary><pre>${escapeHtml(question.raw_block || '')}</pre></details>
        </div>
        <div>
          <h4>Assets</h4>
          <div class="assets">${assetHtml || '<div class="muted">No linked assets</div>'}</div>
          <h4>Page previews</h4>
          ${pages.join('')}
        </div>
      </div>
    </div>`;
}

async function showDocument(documentId, focusQuestionId=null) {
  const doc = await api(`/api/documents/${documentId}`);
  currentDocument = doc;
  const root = document.getElementById('documentView');
  let html = `<div class="card"><h2 style="margin-top:0">${doc.source_pdf}</h2>
    <div class="muted">Questions: ${(doc.sections || []).reduce((a,s)=>a+s.questions.length,0)} | Confidence: ${doc.document_parse_confidence}</div>`;
  if ((doc.preface || []).length) {
    html += `<details><summary>Preface</summary><pre>${escapeHtml(doc.preface.map(x => x.text).join('\n\n'))}</pre></details>`;
  }
  (doc.sections || []).forEach(section => {
    html += `<div class="card"><h3 style="margin-top:0">${section.title || section.section_id}</h3>`;
    (section.directions || []).forEach(dir => {
      html += `<div class="option"><strong>${dir.direction_id}</strong><div>${escapeHtml(dir.text)}</div></div>`;
    });
    (section.questions || []).forEach(question => {
      html += renderQuestionEditor(doc, question);
    });
    html += `</div>`;
  });
  html += '</div>';
  root.innerHTML = html;
  if (focusQuestionId) {
    const el = document.getElementById(focusQuestionId);
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}

async function startExtraction() {
  const input_dir = document.getElementById('inputDir').value.trim();
  const engine = document.getElementById('engine').value;
  await api('/api/extract', { method: 'POST', body: JSON.stringify({ input_dir, engine }) });
  await refreshAll();
}

async function saveQuestion(documentId, questionId) {
  let options = [];
  let correct_answer = {};
  try {
    options = JSON.parse(document.getElementById(`options_${questionId}`).value || '[]');
    correct_answer = JSON.parse(document.getElementById(`answer_${questionId}`).value || '{}');
  } catch (err) {
    alert('Options or answer JSON is invalid');
    return;
  }
  const payload = {
    stem: document.getElementById(`stem_${questionId}`).value,
    options,
    correct_answer,
    solution: document.getElementById(`solution_${questionId}`).value,
  };
  await api(`/api/documents/${documentId}/questions/${questionId}`, { method: 'POST', body: JSON.stringify(payload) });
  alert('Saved');
  await showDocument(documentId, questionId);
  await loadReview();
}

async function markReviewed(documentId, questionId) {
  await api(`/api/documents/${documentId}/questions/${questionId}`, {
    method: 'POST', body: JSON.stringify({ needs_review: false })
  });
  await showDocument(documentId, questionId);
  await loadReview();
}

async function refreshAll() {
  await loadJobs();
  await loadDocuments();
  await loadReview();
}

function escapeHtml(str) {
  return String(str || '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;');
}

loadConfig().then(refreshAll);
setInterval(loadJobs, 4000);
</script>
</body>
</html>'''
