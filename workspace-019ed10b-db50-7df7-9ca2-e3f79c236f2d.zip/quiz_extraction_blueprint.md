# Quiz Extraction Blueprint for Bulk PDF Processing

## Goal

Convert thousands of exam/question-paper PDFs into a **canonical JSON format** that preserves:

- document metadata
- preface / intro text
- section directions / instructions
- every question
- answer options
- correct answer
- explanations / solutions when available
- all related images / diagrams / tables
- provenance (page number, bounding boxes, source PDF)

---

## Recommended Architecture

### Stage 1: Raw conversion with Docling

Use Docling as the **layout + OCR + image extraction layer**.

Suggested settings:

- `do_ocr=True`
- `do_table_structure=True`
- `generate_picture_images=True`
- `generate_page_images=True`
- `images_scale=2.0`

Store the raw Docling output for each PDF:

- `raw/docling_json/<pdf_stem>.json`
- `raw/markdown/<pdf_stem>.md`
- `raw/page_images/<pdf_stem>/page_001.png`
- `raw/picture_images/<pdf_stem>/...`

This raw layer is important because it gives you a debuggable intermediate format.

---

### Stage 2: Deterministic parser

Build a parser that converts Docling output into your quiz JSON.

Primary parsing rules:

1. Detect question boundaries:
   - `Q1.` / `Q 1.` / `1.` / `Question 1`
2. Detect options:
   - `(a)` `(b)` `(c)` `(d)`
   - `A.` `B.` `C.` `D.`
   - numbered options if needed
3. Detect answers:
   - `Ans.(b)`
   - `Answer: (B)`
   - `Correct Answer: B`
   - answer key table at end of file
4. Detect direction blocks:
   - lines like `Instruction:`, `Directions:`, `Read the following...`
   - attach to following questions until next section/instruction block
5. Detect explanation/solution text when present
6. Detect question groups sharing a common stimulus (passage, table, image)

---

### Stage 3: Image attachment

Not every extracted image is useful.

Create an image attachment layer that:

1. extracts image metadata
2. removes repeated logos/watermarks using image hash frequency
3. maps images to the nearest question using:
   - page number
   - bounding box overlap
   - proximity to question text
   - shared section/group context
4. optionally crops the question region from page image if diagram is inline and not extracted well

Each question should contain references to:

- inline diagrams
- charts
- tables
- passage images
- answer-figure images if any

---

### Stage 4: LLM fallback / repair layer

Use an LLM only when deterministic parsing has low confidence.

Typical repair cases:

- OCR noise
- broken option boundaries
- answer key separated from questions
- multi-column reading-order issues
- image-based questions where text alone is insufficient
- grouped directions not attached correctly

Recommended pattern:

- deterministic parser first
- confidence score per question
- send only failed/low-confidence questions to LLM
- require strict JSON output
- validate with schema after LLM response

This keeps cost low and quality high.

---

## Canonical JSON Shape

```json
{
  "document_id": "ssc_selection_post_2025_s3_grad_eng",
  "source_pdf": "SSC-Selection-Post-Graduation-Similar-Paper-Held-on-2-Aug-2025-S3-Eng.pdf",
  "metadata": {
    "title": "SSC Selection Post (Graduation) Similar Paper (Held on 2 Aug 2025 S3)",
    "exam": "SSC Selection Post",
    "language": "en",
    "year": 2025,
    "shift": "S3",
    "pages": 24,
    "source_url": null
  },
  "preface": [
    {
      "text": "General introduction or instructions appearing before the first question.",
      "page_start": 1,
      "page_end": 1
    }
  ],
  "sections": [
    {
      "section_id": "section_1",
      "title": "Reasoning Ability",
      "directions": [
        {
          "direction_id": "dir_1",
          "text": "Read the statements carefully and choose the best answer.",
          "question_range": [1, 5],
          "page_start": 1,
          "page_end": 2
        }
      ],
      "questions": [
        {
          "question_id": "q_1",
          "question_number": 1,
          "type": "mcq_single",
          "stem": "Statements: 1. All engineers are problem-solvers...",
          "options": [
            {"key": "a", "text": "Only I follows"},
            {"key": "b", "text": "Only II follows"},
            {"key": "c", "text": "Both I and II follow"},
            {"key": "d", "text": "Neither I nor II follows"}
          ],
          "correct_answer": {
            "option_key": "b",
            "answer_text": "Only II follows"
          },
          "solution": null,
          "direction_refs": ["dir_1"],
          "assets": [
            {
              "asset_id": "img_q1_1",
              "type": "image",
              "path": "assets/ssc_selection_post_2025_s3_grad_eng/q1_diagram_1.png",
              "page": 1,
              "bbox": [120, 340, 450, 620],
              "role": "question_diagram"
            }
          ],
          "stimulus": null,
          "provenance": {
            "page_start": 1,
            "page_end": 1,
            "source_spans": []
          },
          "parse_confidence": 0.98,
          "needs_review": false
        }
      ]
    }
  ],
  "unassigned_assets": [],
  "document_parse_confidence": 0.94,
  "parser_version": "v1"
}
```

---

## Practical Rules That Improve Quality

### 1. Keep a raw intermediate layer
Never parse directly from PDF into final JSON only.

Keep:
- raw docling JSON
- raw markdown/text
- extracted images
- parser logs
- low-confidence review file

### 2. Add provenance everywhere
For each question store:
- page number(s)
- source PDF name
- optional bounding boxes or text span references

This makes debugging much easier.

### 3. Normalize options and answers
Store both:
- answer key: `b`
- answer text: `Only II follows`

This avoids downstream joining problems.

### 4. Separate directions from stem
Do **not** merge instruction blocks into every stem permanently.
Keep them in their own structure and reference them from affected questions.

### 5. Support grouped stimulus questions
Some PDFs have:
- one passage + multiple questions
- one chart + multiple questions
- one case study + multiple questions

Represent the shared material once as a `stimulus` block and reference it from all linked questions.

### 6. Create a review queue
Flag questions for manual/LLM review when:
- fewer/more than expected options
- no answer found
- duplicate question number
- answer option key not present in options
- very short or empty stem
- OCR confidence is poor
- image is present but no question mapping found

---

## Suggested Confidence Scoring

Start from 1.0 and subtract penalties:

- missing answer: `-0.35`
- fewer than 4 options where 4 expected: `-0.20`
- duplicated option keys: `-0.20`
- stem too short: `-0.15`
- OCR-heavy page: `-0.10`
- image detected but unassigned: `-0.10`
- answer extracted from fuzzy heuristic instead of exact pattern: `-0.10`

If score < `0.80`, route to LLM repair or human review.

---

## Recommended Processing Strategy for 1000s of PDFs

### Pass 1: Fast batch extraction
- run Docling on all PDFs
- save raw outputs
- run deterministic parser
- generate final JSON + confidence report

### Pass 2: Repair failed PDFs only
- run LLM repair only on low-confidence questions/PDFs
- regenerate corrected JSON

### Pass 3: QA sampling
- manually inspect random sample per exam type
- compare extracted answer counts vs question counts
- verify image attachments

---

## Folder Structure

```text
project/
  input_pdfs/
  raw/
    docling_json/
    markdown/
    page_images/
    picture_images/
  output/
    json/
    review/
    logs/
  configs/
    parser_rules.yaml
    exam_profiles.yaml
```

---

## Best Initial Strategy for Your Use Case

For these exam PDFs, start with:

1. **Docling standard pipeline** for all PDFs
2. regex/rule parser for question/option/answer extraction
3. image deduplication + nearest-question mapping
4. LLM fallback only for low-confidence cases

This is usually better than sending every PDF directly to an LLM.

---

## What to Build Next

A good MVP should include:

1. batch PDF runner
2. raw Docling export saver
3. MCQ parser
4. image exporter / deduper
5. JSON validator
6. low-confidence review generator

After that, add:

7. exam-specific rules
8. LLM repair layer
9. dashboard / QA scripts
